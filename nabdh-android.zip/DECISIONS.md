# القرارات التقنية — نبض | Nabdh

## 1. حزمة التطبيق وإصدارات البناء
- **Package ID**: `dz.nabdh.net` (قصير، واضح، يعكس الهوية الجزائرية ومجال الشبكات).
- **SDK**: `minSdk = 26`, `targetSdk = 35`, `compileSdk = 35` مع Java 17 وKotlin 2.0.21 وKSP 2.0.21-1.0.27 (أسرع من KAPT وأكثر استقراراً مع Hilt وRoom).
- **Gradle Version Catalog**: اعتماد `gradle/libs.versions.toml` لتوحيد الإصدارات وضمان التوافق الكامل بين Compose BOM `2024.10.01` وHilt `2.52` وRoom `2.6.1`.

## 2. الخطوط (Cairo و Inter)
- استخدام `androidx.compose.ui:ui-text-google-fonts` مع مزوّد خطوط Google Play Services لتحميل خط **Cairo** (للنصوص العربية) و**Inter** (للأرقام والنصوص اللاتينية) تلقائياً دون تضخيم حجم الـ APK، مع خط احتياطي `FontFamily.SansSerif` عند انقطاع الشبكة.

## 3. التصميم الزجاجي (Glassmorphism)
- على **Android 12+ (API 31+)**: استخدام `Modifier.blur()` الحقيقي على طبقة خلفية الزجاج داخل البطاقة مع حدود متدرجة لامعة وزوايا `28.dp`.
- على **Android 8–11 (API 26–30)**: بديل شفاف عالي الجودة بطبقة ضبابية متعددة التدرجات وحد علوي لامع للحفاظ على القراءة والأداء السلس دون أي تعطل.

## 4. قياسات الشبكة الحقيقية
- **Ping**: قياس زمن اتصال TCP الحقيقي (`Socket.connect` مع `System.nanoTime()`) مع دعم تحليل `/system/bin/ping` عند توفره، لضمان الدقة حتى على الشبكات التي تحجب ICMP.
- **معلومات IP والمزود**: الاستعلام الفعلي من `https://ipwho.is/` مع بديل تلقائي `https://ipapi.co/json/`.
- **اختبار السرعة**: استخدام نقاط `https://speed.cloudflare.com/__down` و`https://speed.cloudflare.com/__up` عبر 6 اتصالات متوازية (قابلة للضبط 4–8) مع مرحلة إحماء مدتها 1.5 ثانية لتجاوز TCP Slow-Start.

## 5. اللغة والاتجاه (RTL/LTR)
- اعتماد `AppCompatDelegate.setApplicationLocales` مع `LocalLayoutDirection` في Compose لتبديل اللغة فورياً بين العربية (RTL) والفرنسية والإنجليزية (LTR) دون إعادة تشغيل قسرية.

## 6. التحقق التلقائي والبناء
- نظراً لعدم توفر Android SDK أو اتصال إنترنت في بيئة التوليد المعزولة، تم تضمين سير عمل GitHub Actions متكامل (`.github/workflows/android-ci.yml`) ينفّذ تلقائياً `./gradlew assembleDebug testDebugUnitTest lintDebug assembleRelease` ويرفع ملفات APK كـ Artifacts، بالإضافة إلى تسجيل الخطوات اليدوية في `MANUAL_STEPS.md`.
