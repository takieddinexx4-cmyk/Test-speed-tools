package dz.nabdh.net.core.network

import org.junit.Assert.assertEquals
import org.junit.Test

class StabilityAnalyzerTest {

    @Test
    fun `consistent low latency samples yield STABLE verdict`() {
        val samples = List(30) { 28.0 + (it % 3) }
        val result = StabilityAnalyzer.evaluate(samples, totalSent = 30)

        assertEquals(StabilityVerdict.STABLE, result.verdict)
        assertEquals(StabilityReason.CONSISTENT_LOW_JITTER, result.reason)
    }

    @Test
    fun `offline or zero received yields UNSTABLE with OFFLINE reason`() {
        val result = StabilityAnalyzer.evaluate(emptyList(), totalSent = 20)

        assertEquals(StabilityVerdict.UNSTABLE, result.verdict)
        assertEquals(StabilityReason.OFFLINE, result.reason)
    }

    @Test
    fun `high packet loss at 5 percent boundary yields UNSTABLE`() {
        val samples = List(19) { 35.0 }
        val result = StabilityAnalyzer.evaluate(samples, totalSent = 20) // 5.0% loss

        assertEquals(StabilityVerdict.UNSTABLE, result.verdict)
        assertEquals(StabilityReason.HIGH_PACKET_LOSS, result.reason)
    }

    @Test
    fun `moderate packet loss around 2 percent yields MODERATE`() {
        val samples = List(49) { 32.0 }
        val result = StabilityAnalyzer.evaluate(samples, totalSent = 50) // 2.0% loss

        assertEquals(StabilityVerdict.MODERATE, result.verdict)
        assertEquals(StabilityReason.MODERATE_LOSS, result.reason)
    }

    @Test
    fun `high standard deviation yields UNSTABLE with HIGH_VARIANCE`() {
        val samples = listOf(20.0, 90.0, 22.0, 95.0, 18.0, 88.0, 25.0, 92.0)
        val result = StabilityAnalyzer.evaluate(samples, totalSent = 8)

        assertEquals(StabilityVerdict.UNSTABLE, result.verdict)
        assertEquals(StabilityReason.HIGH_VARIANCE, result.reason)
    }

    @Test
    fun `moderate variance yields MODERATE verdict`() {
        val samples = listOf(30.0, 52.0, 32.0, 54.0, 31.0, 50.0, 29.0, 53.0)
        val result = StabilityAnalyzer.evaluate(samples, totalSent = 8)

        assertEquals(StabilityVerdict.MODERATE, result.verdict)
        assertEquals(StabilityReason.MODERATE_VARIANCE, result.reason)
    }

    @Test
    fun `frequent spikes yield UNSTABLE with FREQUENT_SPIKES`() {
        val base = MutableList(36) { 30.0 }
        // Add 4 clear spikes that keep stdDev < 25ms while hitting spikeCount >= 4
        base.addAll(listOf(85.0, 86.0, 88.0, 90.0))
        val result = StabilityAnalyzer.evaluate(base, totalSent = 40)

        assertEquals(StabilityVerdict.UNSTABLE, result.verdict)
        assertEquals(StabilityReason.FREQUENT_SPIKES, result.reason)
    }
}
