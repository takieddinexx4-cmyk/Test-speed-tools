package dz.nabdh.net.core.network

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NetworkStatsCalculatorTest {

    @Test
    fun `calculates min avg max jitter and stdDev accurately`() {
        val samples = listOf(20.0, 24.0, 22.0, 26.0, 28.0)
        val stats = NetworkStatsCalculator.calculate(samples, totalSent = 5)

        assertTrue(stats.isReachable)
        assertEquals(20.0, stats.minMs, 0.001)
        assertEquals(24.0, stats.avgMs, 0.001)
        assertEquals(28.0, stats.maxMs, 0.001)
        // diffs: |24-20|=4, |22-24|=2, |26-22|=4, |28-26|=2 -> avg = 3.0
        assertEquals(3.0, stats.jitterMs, 0.001)
        // variance = (16+0+4+4+16)/5 = 8.0 -> sqrt(8.0) ≈ 2.8284
        assertEquals(2.8284, stats.stdDevMs, 0.001)
        assertEquals(0, stats.spikeCount)
        assertEquals(0.0, stats.packetLossPercent, 0.001)
    }

    @Test
    fun `handles empty samples as 100 percent loss and unreachable`() {
        val stats = NetworkStatsCalculator.calculate(emptyList(), totalSent = 10)

        assertFalse(stats.isReachable)
        assertEquals(0.0, stats.avgMs, 0.001)
        assertEquals(100.0, stats.packetLossPercent, 0.001)
        assertEquals(10, stats.sent)
        assertEquals(0, stats.received)
    }

    @Test
    fun `handles partial packet loss and detects spikes`() {
        // Stable around 30ms with two large spikes (120ms, 140ms)
        val samples = listOf(30.0, 31.0, 29.0, 30.0, 31.0, 30.0, 140.0, 30.0)
        val stats = NetworkStatsCalculator.calculate(samples, totalSent = 10)

        assertTrue(stats.isReachable)
        assertEquals(20.0, stats.packetLossPercent, 0.001)
        assertEquals(1, stats.spikeCount)
        assertEquals(8, stats.received)
        assertEquals(10, stats.sent)
    }

    @Test
    fun `single sample yields zero jitter and zero stdDev`() {
        val stats = NetworkStatsCalculator.calculate(listOf(42.5), totalSent = 1)
        assertEquals(42.5, stats.minMs, 0.001)
        assertEquals(42.5, stats.avgMs, 0.001)
        assertEquals(42.5, stats.maxMs, 0.001)
        assertEquals(0.0, stats.jitterMs, 0.001)
        assertEquals(0.0, stats.stdDevMs, 0.001)
    }
}
