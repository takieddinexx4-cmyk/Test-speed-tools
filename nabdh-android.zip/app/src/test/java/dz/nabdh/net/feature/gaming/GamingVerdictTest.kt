package dz.nabdh.net.feature.gaming

import dz.nabdh.net.core.network.NetworkStatsCalculator
import dz.nabdh.net.feature.gaming.data.GamingVerdict
import dz.nabdh.net.feature.gaming.data.GamingVerdictEvaluator
import org.junit.Assert.assertEquals
import org.junit.Test

class GamingVerdictTest {

    @Test
    fun `low ping low jitter zero loss is READY`() {
        val stats = NetworkStatsCalculator.calculate(listOf(42.0, 44.0, 43.0, 45.0, 44.0), totalSent = 5)
        assertEquals(GamingVerdict.READY, GamingVerdictEvaluator.evaluate(stats))
    }

    @Test
    fun `medium ping around 85ms is ACCEPTABLE`() {
        val stats = NetworkStatsCalculator.calculate(listOf(82.0, 86.0, 84.0, 88.0), totalSent = 4)
        assertEquals(GamingVerdict.ACCEPTABLE, GamingVerdictEvaluator.evaluate(stats))
    }

    @Test
    fun `high ping or packet loss is POOR`() {
        val stats = NetworkStatsCalculator.calculate(listOf(145.0, 150.0, 148.0), totalSent = 3)
        assertEquals(GamingVerdict.POOR, GamingVerdictEvaluator.evaluate(stats))
    }

    @Test
    fun `unreachable server is POOR`() {
        val stats = NetworkStatsCalculator.calculate(emptyList(), totalSent = 6)
        assertEquals(GamingVerdict.POOR, GamingVerdictEvaluator.evaluate(stats))
    }
}
