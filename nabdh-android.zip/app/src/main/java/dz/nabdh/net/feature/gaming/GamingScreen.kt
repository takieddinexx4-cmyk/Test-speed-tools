package dz.nabdh.net.feature.gaming

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Layers
import androidx.compose.material.icons.rounded.Radar
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dz.nabdh.net.R
import dz.nabdh.net.feature.gaming.data.GamingVerdict
import dz.nabdh.net.feature.gaming.overlay.GamingOverlayService
import dz.nabdh.net.ui.components.GlassButton
import dz.nabdh.net.ui.components.GlassCard
import dz.nabdh.net.ui.components.GlassShimmerBox
import dz.nabdh.net.ui.components.StatusPill
import dz.nabdh.net.ui.theme.NabdhCyan
import dz.nabdh.net.ui.theme.NabdhTurquoise
import dz.nabdh.net.ui.theme.StatusBad
import dz.nabdh.net.ui.theme.StatusGood
import dz.nabdh.net.ui.theme.StatusModerate
import java.util.Locale

@Composable
fun GamingScreen(
    viewModel: GamingViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val lang = settings.languageTag

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.gaming_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            IconButton(onClick = { viewModel.loadGames(forceRefresh = true) }) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = stringResource(R.string.gaming_refresh_catalog),
                    tint = NabdhCyan
                )
            }
        }

        // Game Selector Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            state.games.forEach { game ->
                FilterChip(
                    selected = state.selectedGame?.id == game.id,
                    onClick = { viewModel.selectGame(game) },
                    label = { Text(game.localizedName(lang)) }
                )
            }
        }

        // Action Buttons
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                GlassButton(
                    text = stringResource(R.string.gaming_scan_servers),
                    icon = Icons.Rounded.Radar,
                    enabled = !state.isScanning,
                    onClick = { viewModel.scanSelectedGame() },
                    modifier = Modifier.fillMaxWidth()
                )

                val best = state.results.firstOrNull { it.stats.isReachable }
                val targetRegion = best?.region ?: state.selectedGame?.regions?.firstOrNull()
                GlassButton(
                    text = if (state.overlayRunning) {
                        stringResource(R.string.gaming_overlay_stop)
                    } else {
                        stringResource(R.string.gaming_overlay_start)
                    },
                    icon = Icons.Rounded.Layers,
                    accent = if (state.overlayRunning) StatusBad else NabdhTurquoise,
                    onClick = {
                        if (state.overlayRunning) {
                            GamingOverlayService.stop(context)
                            viewModel.setOverlayRunning(false)
                        } else if (!Settings.canDrawOverlays(context)) {
                            val permIntent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            context.startActivity(permIntent)
                        } else if (targetRegion != null) {
                            GamingOverlayService.start(
                                context = context,
                                host = targetRegion.host,
                                port = targetRegion.port,
                                label = targetRegion.localizedName(lang)
                            )
                            viewModel.setOverlayRunning(true)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = stringResource(R.string.gaming_overlay_perm_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (state.isScanning) {
            repeat(3) {
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GlassShimmerBox(modifier = Modifier.fillMaxWidth(0.6f))
                        GlassShimmerBox(modifier = Modifier.fillMaxWidth(0.4f))
                    }
                }
            }
        } else {
            val best = state.results.firstOrNull { it.stats.isReachable }
            if (best != null) {
                GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = stringResource(R.string.gaming_best_server),
                            style = MaterialTheme.typography.labelLarge,
                            color = NabdhTurquoise
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = best.region.localizedName(lang),
                                style = MaterialTheme.typography.titleLarge,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            VerdictBadge(best.verdict)
                        }
                        Text(
                            text = String.format(
                                Locale.US,
                                "Ping %.0f ms • Jitter %.1f ms • Loss %.0f%%",
                                best.stats.avgMs,
                                best.stats.jitterMs,
                                best.stats.packetLossPercent
                            ),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            state.results.forEach { res ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = res.region.localizedName(lang),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (res.stats.isReachable) {
                                    String.format(
                                        Locale.US,
                                        "Ping %.0f ms • Jitter %.1f ms • Loss %.0f%%",
                                        res.stats.avgMs,
                                        res.stats.jitterMs,
                                        res.stats.packetLossPercent
                                    )
                                } else {
                                    stringResource(R.string.overlay_timeout)
                                },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        VerdictBadge(res.verdict)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(72.dp))
    }
}

@Composable
private fun VerdictBadge(verdict: GamingVerdict) {
    val (label, color) = when (verdict) {
        GamingVerdict.READY -> stringResource(R.string.gaming_verdict_ready) to StatusGood
        GamingVerdict.ACCEPTABLE -> stringResource(R.string.gaming_verdict_acceptable) to StatusModerate
        GamingVerdict.POOR -> stringResource(R.string.gaming_verdict_poor) to StatusBad
    }
    StatusPill(label = label, color = color)
}
