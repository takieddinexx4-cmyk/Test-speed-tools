package dz.nabdh.net.core.share

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.core.content.FileProvider
import dz.nabdh.net.R
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ShareableResult(
    val title: String,
    val downloadLabel: String,
    val uploadLabel: String,
    val pingMs: Double,
    val jitterMs: Double,
    val isp: String?,
    val timestampMs: Long = System.currentTimeMillis()
)

/**
 * Renders a branded Nabdh glass summary card as a PNG image and shares it via Android FileProvider.
 */
object ResultImageSharer {

    fun shareResultCard(context: Context, result: ShareableResult) {
        val bitmap = renderBitmap(context, result)
        val outDir = File(context.cacheDir, "shared_results").apply { mkdirs() }
        val outFile = File(outDir, "nabdh_result_${System.currentTimeMillis()}.png")
        FileOutputStream(outFile).use { stream ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        }
        bitmap.recycle()

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "image/png"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "${context.getString(R.string.app_name)} — ${result.downloadLabel} / ${result.uploadLabel}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(shareIntent, context.getString(R.string.share_result_title))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun renderBitmap(context: Context, result: ShareableResult): Bitmap {
        val width = 1080
        val height = 720
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        // Deep blue-turquoise gradient background
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(Color.parseColor("#050B16"), Color.parseColor("#0B2545"), Color.parseColor("#052B33")),
                null,
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Subtle Algerian tricolor accent bar at top
        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        barPaint.color = Color.parseColor("#00A859")
        canvas.drawRect(0f, 0f, width / 3f, 10f, barPaint)
        barPaint.color = Color.WHITE
        canvas.drawRect(width / 3f, 0f, 2f * width / 3f, 10f, barPaint)
        barPaint.color = Color.parseColor("#D21034")
        canvas.drawRect(2f * width / 3f, 0f, width.toFloat(), 10f, barPaint)

        // Glass card container
        val cardRect = RectF(56f, 64f, width - 56f, height - 64f)
        val cardFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#44142B4F") }
        val cardBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3f
            color = Color.parseColor("#6600D4FF")
        }
        canvas.drawRoundRect(cardRect, 48f, 48f, cardFill)
        canvas.drawRoundRect(cardRect, 48f, 48f, cardBorder)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#00E5C4")
            textSize = 46f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        canvas.drawText("نبض | Nabdh", 104f, 148f, titlePaint)

        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9BB2D1")
            textSize = 28f
        }
        val dateText = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(result.timestampMs))
        canvas.drawText("${result.title}  •  $dateText", 104f, 198f, subPaint)

        val metricLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#9BB2D1")
            textSize = 28f
        }
        val metricValuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 62f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        // Download & Upload row
        canvas.drawText(context.getString(R.string.label_download), 104f, 300f, metricLabelPaint)
        canvas.drawText(result.downloadLabel, 104f, 376f, metricValuePaint)

        canvas.drawText(context.getString(R.string.label_upload), 560f, 300f, metricLabelPaint)
        canvas.drawText(result.uploadLabel, 560f, 376f, metricValuePaint)

        // Ping & Jitter row
        metricValuePaint.textSize = 48f
        metricValuePaint.color = Color.parseColor("#00D4FF")
        canvas.drawText(context.getString(R.string.label_ping), 104f, 485f, metricLabelPaint)
        canvas.drawText(String.format(Locale.US, "%.1f ms", result.pingMs), 104f, 548f, metricValuePaint)

        canvas.drawText(context.getString(R.string.label_jitter), 560f, 485f, metricLabelPaint)
        canvas.drawText(String.format(Locale.US, "%.1f ms", result.jitterMs), 560f, 548f, metricValuePaint)

        // Footer ISP
        val footerText = result.isp?.takeIf { it.isNotBlank() } ?: "Nabdh Network Diagnostics (DZ)"
        canvas.drawText(footerText, 104f, 622f, subPaint)
        return bmp
    }
}
