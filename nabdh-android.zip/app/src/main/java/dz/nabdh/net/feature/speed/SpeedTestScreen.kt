package dz.nabdh.net.feature.speed

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dz.nabdh.net.R
import dz.nabdh.net.core.network.NetworkType
import dz.nabdh.net.core.network.SpeedPhase
import dz.nabdh.net.core.share.ResultImageSharer
import dz.nabdh.net.core.share.ShareableResult
import dz.nabdh.net.ui.components.AnimatedSpeedGauge
import dz.nabdh.net.ui.components.GlassButton
import dz.nabdh.net.ui.components.GlassCard
import dz.nabdh.net.ui.components.GlassShimmerBox
import dz.nabdh.net.ui.components.LiveMetricLineChart
import dz.nabdh.net.ui.components.StatusPill
import dz.nabdh.net.ui.components.formatSpeed
import dz.nabdh.net.ui.theme.NabdhCyan
import dz.nabdh.net.ui.theme.NabdhTurquoise
import dz.nabdh.net.ui.theme.StatusBad
import dz.nabdh.net.ui.theme.StatusGood
import dz.nabdh.net.ui.theme.StatusModerate
import java.util.Locale

@Composable
fun SpeedTestScreen(
    viewModel: SpeedTestViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val phaseText = when (state.speedUpdate.phase) {
        SpeedPhase.IDLE -> stringResource(R.string.phase_idle)
        SpeedPhase.PING -> stringResource(R.string.phase_ping)
        SpeedPhase.DOWNLOAD_WARMUP -> stringResource(R.string.phase_download_warmup)
        SpeedPhase.DOWNLOAD -> stringResource(R.string.phase_download)
        SpeedPhase.UPLOAD_WARMUP -> stringResource(R.string.phase_upload_warmup)
        SpeedPhase.UPLOAD -> stringResource(R.string.phase_upload)
        SpeedPhase.COMPLETED -> stringResource(R.string.phase_completed)
        SpeedPhase.CANCELLED -> stringResource(R.string.phase_cancelled)
        SpeedPhase.ERROR -> stringResource(R.string.phase_error)
    }

    val gaugeSpeed = when (state.speedUpdate.phase) {
        SpeedPhase.DOWNLOAD_WARMUP, SpeedPhase.DOWNLOAD, SpeedPhase.UPLOAD_WARMUP, SpeedPhase.UPLOAD ->
            state.speedUpdate.currentMbps
        SpeedPhase.COMPLETED -> state.speedUpdate.downloadMbps
        else -> 0.0
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header & Live Connection Card
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val conn = state.connection
                    val online = conn?.isInternetReachable == true
                    StatusPill(
                        label = when {
                            state.isRefreshingConnection -> stringResource(R.string.status_checking)
                            online -> stringResource(R.string.status_online)
                            else -> stringResource(R.string.status_no_internet)
                        },
                        color = when {
                            state.isRefreshingConnection -> StatusModerate
                            online -> StatusGood
                            else -> StatusBad
                        }
                    )
                    IconButton(onClick = { viewModel.refreshConnection() }) {
                        Icon(
                            imageVector = Icons.Rounded.Refresh,
                            contentDescription = stringResource(R.string.action_refresh),
                            tint = NabdhCyan
                        )
                    }
                }

                if (state.isRefreshingConnection) {
                    GlassShimmerBox(modifier = Modifier.fillMaxWidth(0.75f))
                    GlassShimmerBox(modifier = Modifier.fillMaxWidth(0.55f))
                } else {
                    val conn = state.connection
                    val netLabel = when (conn?.networkType) {
                        NetworkType.WIFI -> stringResource(R.string.net_wifi)
                        NetworkType.CELLULAR_5G -> stringResource(R.string.net_5g)
                        NetworkType.CELLULAR_4G -> stringResource(R.string.net_4g)
                        NetworkType.CELLULAR_3G -> stringResource(R.string.net_3g)
                        NetworkType.CELLULAR_OTHER -> stringResource(R.string.net_cellular)
                        NetworkType.ETHERNET -> stringResource(R.string.net_ethernet)
                        else -> stringResource(R.string.net_offline)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricPair(stringResource(R.string.label_network), netLabel)
                        MetricPair(
                            stringResource(R.string.label_signal),
                            conn?.signalDbm?.let { "$it dBm (${conn.signalBars}/4)" } ?: "${conn?.signalBars ?: 0}/4"
                        )
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricPair(
                            stringResource(R.string.label_isp),
                            conn?.isp ?: stringResource(R.string.label_unknown)
                        )
                        MetricPair(
                            stringResource(R.string.label_ip),
                            conn?.publicIp ?: stringResource(R.string.label_unknown)
                        )
                    }
                }
            }
        }

        // Main Speed Gauge & Live Chart Card
        GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AnimatedSpeedGauge(
                    speedMbps = gaugeSpeed,
                    unit = settings.speedUnit,
                    phaseLabel = phaseText
                )

                if (state.chartPoints.size >= 2) {
                    LiveMetricLineChart(
                        points = state.chartPoints,
                        lineColor = if (state.speedUpdate.phase == SpeedPhase.UPLOAD) NabdhTurquoise else NabdhCyan
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    MetricPair(
                        stringResource(R.string.label_download),
                        formatSpeed(state.speedUpdate.downloadMbps, settings.speedUnit)
                    )
                    MetricPair(
                        stringResource(R.string.label_upload),
                        formatSpeed(state.speedUpdate.uploadMbps, settings.speedUnit)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val pingVal = if (state.speedUpdate.pingMs > 0) state.speedUpdate.pingMs else (state.quickPing?.avgMs ?: 0.0)
                    val jitterVal = if (state.speedUpdate.jitterMs > 0) state.speedUpdate.jitterMs else (state.quickPing?.jitterMs ?: 0.0)
                    MetricPair(stringResource(R.string.label_ping), String.format(Locale.US, "%.1f ms", pingVal))
                    MetricPair(stringResource(R.string.label_jitter), String.format(Locale.US, "%.1f ms", jitterVal))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (state.isRunning) {
                        GlassButton(
                            text = stringResource(R.string.action_cancel),
                            icon = Icons.Rounded.Close,
                            accent = StatusBad,
                            onClick = { viewModel.cancelSpeedTest() },
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        GlassButton(
                            text = stringResource(R.string.action_start_speed),
                            icon = Icons.Rounded.PlayArrow,
                            onClick = { viewModel.startSpeedTest() },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    if (state.speedUpdate.phase == SpeedPhase.COMPLETED) {
                        GlassButton(
                            text = stringResource(R.string.action_share_image),
                            icon = Icons.Rounded.Share,
                            accent = NabdhTurquoise,
                            onClick = {
                                ResultImageSharer.shareResultCard(
                                    context = context,
                                    result = ShareableResult(
                                        title = context.getString(R.string.nav_speed),
                                        downloadLabel = formatSpeed(state.speedUpdate.downloadMbps, settings.speedUnit),
                                        uploadLabel = formatSpeed(state.speedUpdate.uploadMbps, settings.speedUnit),
                                        pingMs = state.speedUpdate.pingMs,
                                        jitterMs = state.speedUpdate.jitterMs,
                                        isp = state.connection?.isp
                                    )
                                )
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Quick Ping Details (Min / Avg / Max)
        state.quickPing?.let { qp ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricPair(stringResource(R.string.label_min), String.format(Locale.US, "%.1f ms", qp.minMs))
                    MetricPair(stringResource(R.string.label_avg), String.format(Locale.US, "%.1f ms", qp.avgMs))
                    MetricPair(stringResource(R.string.label_max), String.format(Locale.US, "%.1f ms", qp.maxMs))
                    MetricPair(stringResource(R.string.label_loss), String.format(Locale.US, "%.0f%%", qp.packetLossPercent))
                }
            }
        }

        Spacer(modifier = Modifier.height(72.dp))
    }
}

@Composable
private fun MetricPair(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
