package dz.nabdh.net.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MeasurementDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: MeasurementEntity): Long

    @Query("SELECT * FROM measurements ORDER BY timestampMs DESC")
    fun observeAll(): Flow<List<MeasurementEntity>>

    @Query("SELECT * FROM measurements WHERE timestampMs >= :sinceMs ORDER BY timestampMs ASC")
    fun observeSince(sinceMs: Long): Flow<List<MeasurementEntity>>

    @Query("DELETE FROM measurements WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM measurements")
    suspend fun clearAll()
}
