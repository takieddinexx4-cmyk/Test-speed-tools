package dz.nabdh.net.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

data class GlassColors(
    val surface: Color,
    val surfaceElevated: Color,
    val borderStart: Color,
    val borderEnd: Color,
    val isDark: Boolean
)

val LocalGlassColors = staticCompositionLocalOf {
    GlassColors(
        surface = Color(0x33132544),
        surfaceElevated = Color(0x4D18315A),
        borderStart = Color(0x70FFFFFF),
        borderEnd = Color(0x2000D4FF),
        isDark = true
    )
}

private val DarkColorScheme = darkColorScheme(
    primary = NabdhCyan,
    onPrimary = NabdhMidnight,
    secondary = NabdhTurquoise,
    onSecondary = NabdhMidnight,
    tertiary = DzEmerald,
    background = NabdhMidnight,
    onBackground = DarkInkPrimary,
    surface = NabdhNavy,
    onSurface = DarkInkPrimary,
    surfaceVariant = NabdhSlate,
    onSurfaceVariant = DarkInkSecondary,
    error = StatusBad
)

private val LightColorScheme = lightColorScheme(
    primary = NabdhDeepBlue,
    onPrimary = DzPureWhite,
    secondary = DzEmerald,
    onSecondary = DzPureWhite,
    tertiary = NabdhTurquoise,
    background = LightBgMid,
    onBackground = LightInkPrimary,
    surface = Color.White,
    onSurface = LightInkPrimary,
    surfaceVariant = LightBgTop,
    onSurfaceVariant = LightInkSecondary,
    error = DzCrimson
)

@Composable
fun NabdhTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    isArabic: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val glassColors = if (darkTheme) {
        GlassColors(
            surface = Color(0x4211223E),
            surfaceElevated = Color(0x5C172F54),
            borderStart = Color(0x66FFFFFF),
            borderEnd = Color(0x2800E5C4),
            isDark = true
        )
    } else {
        GlassColors(
            surface = Color(0xA6FFFFFF),
            surfaceElevated = Color(0xCCFFFFFF),
            borderStart = Color(0xEEFFFFFF),
            borderEnd = Color(0x440A4DFF),
            isDark = false
        )
    }
    val direction = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(
        LocalGlassColors provides glassColors,
        LocalLayoutDirection provides direction
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = nabdhTypography(isArabic = isArabic),
            content = content
        )
    }
}
