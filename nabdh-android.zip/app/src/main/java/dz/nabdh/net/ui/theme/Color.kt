package dz.nabdh.net.ui.theme

import androidx.compose.ui.graphics.Color

// Brand & Pulse Palette (Blue-Turquoise + Subtle Algerian Flag Accents)
val NabdhCyan = Color(0xFF00D4FF)
val NabdhTurquoise = Color(0xFF00E5C4)
val NabdhDeepBlue = Color(0xFF0A4DFF)
val NabdhMidnight = Color(0xFF050B16)
val NabdhNavy = Color(0xFF0B162C)
val NabdhSlate = Color(0xFF12233F)

// Algerian Heritage Subtle Accents
val DzEmerald = Color(0xFF00A859)
val DzCrimson = Color(0xFFD21034)
val DzPureWhite = Color(0xFFF8FAFC)

// Status Semantic Colors
val StatusGood = Color(0xFF10E59B)
val StatusModerate = Color(0xFFFFB547)
val StatusBad = Color(0xFFFF4D6D)

// Light Theme Surfaces
val LightBgTop = Color(0xFFEAF4FF)
val LightBgMid = Color(0xFFF3FAFD)
val LightBgBottom = Color(0xFFE6F7F4)
val LightInkPrimary = Color(0xFF0A1628)
val LightInkSecondary = Color(0xFF475B75)

// Dark Theme Text
val DarkInkPrimary = Color(0xFFF1F7FF)
val DarkInkSecondary = Color(0xFF9BB2D1)
