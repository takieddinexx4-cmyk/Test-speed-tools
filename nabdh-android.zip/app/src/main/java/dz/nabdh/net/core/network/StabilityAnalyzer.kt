package dz.nabdh.net.core.network

enum class StabilityVerdict {
    STABLE, MODERATE, UNSTABLE
}

enum class StabilityReason {
    OFFLINE,
    HIGH_PACKET_LOSS,
    HIGH_VARIANCE,
    FREQUENT_SPIKES,
    MODERATE_VARIANCE,
    MODERATE_LOSS,
    CONSISTENT_LOW_JITTER
}

data class StabilityEvaluation(
    val stats: PingStats,
    val verdict: StabilityVerdict,
    val reason: StabilityReason
)

/**
 * Evaluates connection stability using standard deviation, spike count, and packet loss.
 */
object StabilityAnalyzer {

    fun evaluate(samplesMs: List<Double>, totalSent: Int = samplesMs.size): StabilityEvaluation {
        val stats = NetworkStatsCalculator.calculate(samplesMs, totalSent)
        if (!stats.isReachable) {
            return StabilityEvaluation(stats, StabilityVerdict.UNSTABLE, StabilityReason.OFFLINE)
        }

        // Unstable conditions
        if (stats.packetLossPercent >= 5.0) {
            return StabilityEvaluation(stats, StabilityVerdict.UNSTABLE, StabilityReason.HIGH_PACKET_LOSS)
        }
        if (stats.stdDevMs >= 25.0) {
            return StabilityEvaluation(stats, StabilityVerdict.UNSTABLE, StabilityReason.HIGH_VARIANCE)
        }
        val spikeRatio = if (stats.received > 0) stats.spikeCount.toDouble() / stats.received else 0.0
        if (stats.spikeCount >= 4 || spikeRatio >= 0.12) {
            return StabilityEvaluation(stats, StabilityVerdict.UNSTABLE, StabilityReason.FREQUENT_SPIKES)
        }

        // Moderate conditions
        if (stats.packetLossPercent >= 1.5) {
            return StabilityEvaluation(stats, StabilityVerdict.MODERATE, StabilityReason.MODERATE_LOSS)
        }
        if (stats.stdDevMs >= 10.0 || stats.jitterMs >= 12.0 || stats.spikeCount >= 2) {
            return StabilityEvaluation(stats, StabilityVerdict.MODERATE, StabilityReason.MODERATE_VARIANCE)
        }

        return StabilityEvaluation(stats, StabilityVerdict.STABLE, StabilityReason.CONSISTENT_LOW_JITTER)
    }
}
