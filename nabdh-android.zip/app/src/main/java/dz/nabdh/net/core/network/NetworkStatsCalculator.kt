package dz.nabdh.net.core.network

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

data class PingStats(
    val minMs: Double,
    val avgMs: Double,
    val maxMs: Double,
    val jitterMs: Double,
    val stdDevMs: Double,
    val spikeCount: Int,
    val sent: Int,
    val received: Int,
    val packetLossPercent: Double
) {
    val isReachable: Boolean get() = received > 0
}

/**
 * Pure Kotlin statistics engine for Ping RTT samples, RFC 3550 jitter, standard deviation, and spikes.
 */
object NetworkStatsCalculator {

    fun calculate(samplesMs: List<Double>, totalSent: Int = samplesMs.size): PingStats {
        val safeSent = max(totalSent, samplesMs.size)
        if (samplesMs.isEmpty()) {
            val loss = if (safeSent == 0) 0.0 else 100.0
            return PingStats(
                minMs = 0.0,
                avgMs = 0.0,
                maxMs = 0.0,
                jitterMs = 0.0,
                stdDevMs = 0.0,
                spikeCount = 0,
                sent = safeSent,
                received = 0,
                packetLossPercent = loss
            )
        }

        val minVal = samplesMs.min()
        val maxVal = samplesMs.max()
        val avgVal = samplesMs.average()

        // Mean absolute difference between consecutive RTTs
        val jitter = if (samplesMs.size < 2) {
            0.0
        } else {
            var diffSum = 0.0
            for (i in 1 until samplesMs.size) {
                diffSum += abs(samplesMs[i] - samplesMs[i - 1])
            }
            diffSum / (samplesMs.size - 1)
        }

        // Population standard deviation
        val variance = samplesMs.sumOf { (it - avgVal) * (it - avgVal) } / samplesMs.size
        val stdDev = sqrt(variance)

        // Spike threshold: sample exceeds avg + max(25ms, 2 * stdDev)
        val spikeThreshold = avgVal + max(25.0, 2.0 * stdDev)
        val spikes = samplesMs.count { it > spikeThreshold }

        val lost = (safeSent - samplesMs.size).coerceAtLeast(0)
        val lossPct = if (safeSent == 0) 0.0 else (lost.toDouble() / safeSent.toDouble()) * 100.0

        return PingStats(
            minMs = minVal,
            avgMs = avgVal,
            maxMs = maxVal,
            jitterMs = jitter,
            stdDevMs = stdDev,
            spikeCount = spikes,
            sent = safeSent,
            received = samplesMs.size,
            packetLossPercent = lossPct.coerceIn(0.0, 100.0)
        )
    }
}
