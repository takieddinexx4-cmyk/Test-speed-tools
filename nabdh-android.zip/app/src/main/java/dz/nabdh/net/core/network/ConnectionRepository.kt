package dz.nabdh.net.core.network

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

enum class NetworkType {
    WIFI, CELLULAR_5G, CELLULAR_4G, CELLULAR_3G, CELLULAR_OTHER, ETHERNET, OFFLINE
}

data class ConnectionSnapshot(
    val networkType: NetworkType,
    val isInternetReachable: Boolean,
    val signalDbm: Int?,
    val signalBars: Int,
    val linkSpeedMbps: Int?,
    val frequencyMhz: Int?,
    val publicIp: String?,
    val isp: String?,
    val city: String?,
    val country: String?,
    val asn: String?
)

@Serializable
private data class IpWhoIsResponse(
    val success: Boolean = false,
    val ip: String? = null,
    val country: String? = null,
    val city: String? = null,
    val connection: IpWhoConnection? = null
)

@Serializable
private data class IpWhoConnection(
    val isp: String? = null,
    val org: String? = null,
    val asn: Int? = null
)

@Serializable
private data class IpApiFallbackResponse(
    val ip: String? = null,
    val org: String? = null,
    val city: String? = null,
    @SerialName("country_name") val countryName: String? = null,
    val asn: String? = null
)

@Singleton
class ConnectionRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    @Named("probeClient") private val httpClient: OkHttpClient,
    private val json: Json
) {

    suspend fun inspectConnection(): ConnectionSnapshot = withContext(Dispatchers.IO) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetwork
        val caps = activeNetwork?.let { cm.getNetworkCapabilities(it) }

        if (caps == null) {
            return@withContext offlineSnapshot()
        }

        val networkType = detectNetworkType(caps)
        val (signalDbm, signalBars, linkSpeed, freq) = readSignalMetrics(networkType, caps)

        val reachable = verifyRealInternetReachability()
        if (!reachable) {
            return@withContext ConnectionSnapshot(
                networkType = networkType,
                isInternetReachable = false,
                signalDbm = signalDbm,
                signalBars = signalBars,
                linkSpeedMbps = linkSpeed,
                frequencyMhz = freq,
                publicIp = null,
                isp = null,
                city = null,
                country = null,
                asn = null
            )
        }

        val ipMeta = fetchIpAndIsp()
        ConnectionSnapshot(
            networkType = networkType,
            isInternetReachable = true,
            signalDbm = signalDbm,
            signalBars = signalBars,
            linkSpeedMbps = linkSpeed,
            frequencyMhz = freq,
            publicIp = ipMeta?.publicIp,
            isp = ipMeta?.isp,
            city = ipMeta?.city,
            country = ipMeta?.country,
            asn = ipMeta?.asn
        )
    }

    private fun offlineSnapshot() = ConnectionSnapshot(
        networkType = NetworkType.OFFLINE,
        isInternetReachable = false,
        signalDbm = null,
        signalBars = 0,
        linkSpeedMbps = null,
        frequencyMhz = null,
        publicIp = null,
        isp = null,
        city = null,
        country = null,
        asn = null
    )

    @SuppressLint("MissingPermission")
    private fun detectNetworkType(caps: NetworkCapabilities): NetworkType {
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                val hasPhonePerm = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_PHONE_STATE
                ) == PackageManager.PERMISSION_GRANTED
                if (!hasPhonePerm) return NetworkType.CELLULAR_OTHER

                val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
                val dataType = runCatching { tm.dataNetworkType }.getOrDefault(TelephonyManager.NETWORK_TYPE_UNKNOWN)
                when (dataType) {
                    TelephonyManager.NETWORK_TYPE_NR -> NetworkType.CELLULAR_5G
                    TelephonyManager.NETWORK_TYPE_LTE -> NetworkType.CELLULAR_4G
                    TelephonyManager.NETWORK_TYPE_UMTS,
                    TelephonyManager.NETWORK_TYPE_HSDPA,
                    TelephonyManager.NETWORK_TYPE_HSUPA,
                    TelephonyManager.NETWORK_TYPE_HSPA,
                    TelephonyManager.NETWORK_TYPE_HSPAP -> NetworkType.CELLULAR_3G
                    else -> NetworkType.CELLULAR_OTHER
                }
            }
            else -> NetworkType.OFFLINE
        }
    }

    private data class SignalMetrics(
        val dbm: Int?,
        val bars: Int,
        val linkSpeedMbps: Int?,
        val frequencyMhz: Int?
    )

    @Suppress("DEPRECATION")
    private fun readSignalMetrics(type: NetworkType, caps: NetworkCapabilities): SignalMetrics {
        if (type == NetworkType.WIFI) {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val info = wifiManager?.connectionInfo
            val rssi = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && caps.signalStrength != Int.MIN_VALUE) {
                caps.signalStrength
            } else {
                info?.rssi
            }
            val bars = when {
                rssi == null || rssi <= -100 -> 1
                rssi >= -55 -> 4
                rssi >= -67 -> 3
                rssi >= -80 -> 2
                else -> 1
            }
            val speed = info?.linkSpeed?.takeIf { it > 0 }
            val freq = info?.frequency?.takeIf { it > 0 }
            return SignalMetrics(rssi, bars, speed, freq)
        }

        if (type == NetworkType.ETHERNET) {
            return SignalMetrics(null, 4, null, null)
        }

        if (type != NetworkType.OFFLINE) {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
            val level = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                runCatching { tm?.signalStrength?.level ?: 2 }.getOrDefault(2)
            } else {
                2
            }
            return SignalMetrics(null, level.coerceIn(0, 4), null, null)
        }

        return SignalMetrics(null, 0, null, null)
    }

    private fun verifyRealInternetReachability(): Boolean {
        val probes = listOf(
            "https://connectivitycheck.gstatic.com/generate_204",
            "https://1.1.1.1/cdn-cgi/trace"
        )
        for (url in probes) {
            val ok = runCatching {
                val req = Request.Builder().url(url).get().build()
                httpClient.newCall(req).execute().use { resp ->
                    resp.code in 200..299
                }
            }.getOrDefault(false)
            if (ok) return true
        }
        return false
    }

    private data class IpMeta(
        val publicIp: String?,
        val isp: String?,
        val city: String?,
        val country: String?,
        val asn: String?
    )

    private fun fetchIpAndIsp(): IpMeta? {
        // Primary: ipwho.is (no key required, fast HTTPS JSON)
        val primary = runCatching {
            val req = Request.Builder().url("https://ipwho.is/").get().build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val body = resp.body?.string().orEmpty()
                val parsed = json.decodeFromString<IpWhoIsResponse>(body)
                if (!parsed.success) return@use null
                IpMeta(
                    publicIp = parsed.ip,
                    isp = parsed.connection?.isp ?: parsed.connection?.org,
                    city = parsed.city,
                    country = parsed.country,
                    asn = parsed.connection?.asn?.let { "AS$it" }
                )
            }
        }.getOrNull()
        if (primary != null) return primary

        // Fallback: ipapi.co
        return runCatching {
            val req = Request.Builder().url("https://ipapi.co/json/").get().build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val body = resp.body?.string().orEmpty()
                val parsed = json.decodeFromString<IpApiFallbackResponse>(body)
                IpMeta(
                    publicIp = parsed.ip,
                    isp = parsed.org,
                    city = parsed.city,
                    country = parsed.countryName,
                    asn = parsed.asn
                )
            }
        }.getOrNull()
    }
}
