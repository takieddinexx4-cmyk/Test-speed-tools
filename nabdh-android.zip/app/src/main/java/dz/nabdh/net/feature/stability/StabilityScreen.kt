package dz.nabdh.net.feature.stability

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.NetworkCheck
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dz.nabdh.net.R
import dz.nabdh.net.core.network.StabilityReason
import dz.nabdh.net.core.network.StabilityVerdict
import dz.nabdh.net.ui.components.GlassButton
import dz.nabdh.net.ui.components.GlassCard
import dz.nabdh.net.ui.components.LiveMetricLineChart
import dz.nabdh.net.ui.components.StatusPill
import dz.nabdh.net.ui.theme.NabdhCyan
import dz.nabdh.net.ui.theme.NabdhTurquoise
import dz.nabdh.net.ui.theme.StatusBad
import dz.nabdh.net.ui.theme.StatusGood
import dz.nabdh.net.ui.theme.StatusModerate
import java.util.Locale

@Composable
fun StabilityScreen(
    viewModel: StabilityViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = stringResource(R.string.stability_title),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        // Duration Selector & Session Controls
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = stringResource(R.string.stability_duration),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf(30, 60, 120).forEach { sec ->
                        FilterChip(
                            selected = state.selectedDurationSec == sec,
                            onClick = { viewModel.selectDuration(sec) },
                            label = { Text("${sec}s") }
                        )
                    }
                }

                if (state.isRunningStability || state.isRunningPacketLoss) {
                    GlassButton(
                        text = stringResource(R.string.action_cancel),
                        icon = Icons.Rounded.Close,
                        accent = StatusBad,
                        onClick = { viewModel.cancelActive() },
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    GlassButton(
                        text = stringResource(R.string.stability_start),
                        icon = Icons.Rounded.Timeline,
                        onClick = { viewModel.startStability() },
                        modifier = Modifier.fillMaxWidth()
                    )
                    GlassButton(
                        text = stringResource(R.string.stability_loss_start),
                        icon = Icons.Rounded.NetworkCheck,
                        accent = NabdhTurquoise,
                        onClick = { viewModel.startPacketLoss100() },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Live Stability Result Card
        state.stabilityTick?.let { tick ->
            val eval = tick.evaluation
            val verdictColor = when (eval.verdict) {
                StabilityVerdict.STABLE -> StatusGood
                StabilityVerdict.MODERATE -> StatusModerate
                StabilityVerdict.UNSTABLE -> StatusBad
            }
            val verdictText = when (eval.verdict) {
                StabilityVerdict.STABLE -> stringResource(R.string.verdict_stable)
                StabilityVerdict.MODERATE -> stringResource(R.string.verdict_moderate)
                StabilityVerdict.UNSTABLE -> stringResource(R.string.verdict_unstable)
            }
            val reasonText = when (eval.reason) {
                StabilityReason.OFFLINE -> stringResource(R.string.reason_offline)
                StabilityReason.HIGH_PACKET_LOSS -> stringResource(R.string.reason_high_loss)
                StabilityReason.HIGH_VARIANCE -> stringResource(R.string.reason_high_var)
                StabilityReason.FREQUENT_SPIKES -> stringResource(R.string.reason_spikes)
                StabilityReason.MODERATE_VARIANCE -> stringResource(R.string.reason_mod_var)
                StabilityReason.MODERATE_LOSS -> stringResource(R.string.reason_mod_loss)
                StabilityReason.CONSISTENT_LOW_JITTER -> stringResource(R.string.reason_consistent)
            }

            GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatusPill(label = verdictText, color = verdictColor)
                        Text(
                            text = "${tick.elapsedSeconds}s / ${tick.totalSeconds}s",
                            style = MaterialTheme.typography.titleMedium,
                            color = NabdhCyan
                        )
                    }

                    Text(
                        text = reasonText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    val chartValues = tick.samples.mapNotNull { it.rttMs }
                    if (chartValues.size >= 2) {
                        LiveMetricLineChart(points = chartValues, lineColor = verdictColor)
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatCol(stringResource(R.string.label_avg), String.format(Locale.US, "%.1f ms", eval.stats.avgMs))
                        StatCol(stringResource(R.string.label_stddev), String.format(Locale.US, "%.1f ms", eval.stats.stdDevMs))
                        StatCol(stringResource(R.string.label_spikes), "${eval.stats.spikeCount}")
                        StatCol(stringResource(R.string.label_loss), String.format(Locale.US, "%.1f%%", eval.stats.packetLossPercent))
                    }
                }
            }
        }

        // 100-Packet Loss Card
        state.packetLossTick?.let { pl ->
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = stringResource(R.string.label_loss),
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${pl.sent}/100",
                            style = MaterialTheme.typography.titleMedium,
                            color = NabdhTurquoise
                        )
                    }
                    LinearProgressIndicator(
                        progress = { (pl.sent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                        color = NabdhCyan
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StatCol(stringResource(R.string.label_loss), String.format(Locale.US, "%.1f%%", pl.lossPercent))
                        StatCol(stringResource(R.string.label_avg), String.format(Locale.US, "%.1f ms", pl.avgMs))
                        StatCol("OK / Lost", "${pl.received} / ${pl.lost}")
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(72.dp))
    }
}

@Composable
private fun StatCol(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
    }
}
