package dz.nabdh.net.core.network

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import java.util.Collections
import java.util.concurrent.atomic.AtomicLong
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

enum class SpeedPhase {
    IDLE, PING, DOWNLOAD_WARMUP, DOWNLOAD, UPLOAD_WARMUP, UPLOAD, COMPLETED, CANCELLED, ERROR
}

data class SpeedProgressUpdate(
    val phase: SpeedPhase,
    val currentMbps: Double = 0.0,
    val downloadMbps: Double = 0.0,
    val uploadMbps: Double = 0.0,
    val pingMs: Double = 0.0,
    val jitterMs: Double = 0.0,
    val progress: Float = 0f,
    val downloadedBytes: Long = 0L,
    val uploadedBytes: Long = 0L,
    val errorMessage: String? = null
)

/**
 * Real multi-connection (4-8 streams) speed test engine powered by Cloudflare's speed endpoints
 * (`speed.cloudflare.com/__down` and `speed.cloudflare.com/__up`) with warm-up exclusion
 * and instant socket cancellation.
 */
@Singleton
class SpeedTestEngine @Inject constructor(
    @Named("speedClient") private val speedClient: OkHttpClient,
    private val pingEngine: PingEngine
) {

    fun runSpeedTest(
        connections: Int = 6,
        warmUpMs: Long = 1500L,
        measureMs: Long = 8000L
    ): Flow<SpeedProgressUpdate> = channelFlow {
        val streamCount = connections.coerceIn(4, 8)
        val activeCalls = Collections.synchronizedList(mutableListOf<Call>())

        fun abortAllCalls() {
            synchronized(activeCalls) {
                activeCalls.forEach { runCatching { it.cancel() } }
                activeCalls.clear()
            }
        }

        try {
            // 1. Ping phase
            send(SpeedProgressUpdate(phase = SpeedPhase.PING, progress = 0.05f))
            val pingStats = pingEngine.measurePing(host = "speed.cloudflare.com", port = 443, count = 6, intervalMs = 150L)
            if (!pingStats.isReachable) {
                send(SpeedProgressUpdate(phase = SpeedPhase.ERROR, errorMessage = "NO_INTERNET"))
                return@channelFlow
            }

            // 2. Multi-connection Download with warm-up
            val downloadResult = runTransferPhase(
                isDownload = true,
                streamCount = streamCount,
                warmUpMs = warmUpMs,
                measureMs = measureMs,
                activeCalls = activeCalls,
                onTick = { inWarmUp, instantMbps, steadyMbps, phaseProgress, totalBytes ->
                    val overallProgress = 0.10f + phaseProgress * 0.45f
                    trySend(
                        SpeedProgressUpdate(
                            phase = if (inWarmUp) SpeedPhase.DOWNLOAD_WARMUP else SpeedPhase.DOWNLOAD,
                            currentMbps = instantMbps,
                            downloadMbps = steadyMbps,
                            pingMs = pingStats.avgMs,
                            jitterMs = pingStats.jitterMs,
                            progress = overallProgress,
                            downloadedBytes = totalBytes
                        )
                    )
                }
            )

            // 3. Multi-connection Upload with warm-up
            val uploadResult = runTransferPhase(
                isDownload = false,
                streamCount = streamCount,
                warmUpMs = warmUpMs,
                measureMs = measureMs,
                activeCalls = activeCalls,
                onTick = { inWarmUp, instantMbps, steadyMbps, phaseProgress, totalBytes ->
                    val overallProgress = 0.55f + phaseProgress * 0.45f
                    trySend(
                        SpeedProgressUpdate(
                            phase = if (inWarmUp) SpeedPhase.UPLOAD_WARMUP else SpeedPhase.UPLOAD,
                            currentMbps = instantMbps,
                            downloadMbps = downloadResult.mbps,
                            uploadMbps = steadyMbps,
                            pingMs = pingStats.avgMs,
                            jitterMs = pingStats.jitterMs,
                            progress = overallProgress,
                            downloadedBytes = downloadResult.bytes,
                            uploadedBytes = totalBytes
                        )
                    )
                }
            )

            send(
                SpeedProgressUpdate(
                    phase = SpeedPhase.COMPLETED,
                    currentMbps = 0.0,
                    downloadMbps = downloadResult.mbps,
                    uploadMbps = uploadResult.mbps,
                    pingMs = pingStats.avgMs,
                    jitterMs = pingStats.jitterMs,
                    progress = 1f,
                    downloadedBytes = downloadResult.bytes,
                    uploadedBytes = uploadResult.bytes
                )
            )
        } catch (ce: CancellationException) {
            abortAllCalls()
            throw ce
        } catch (e: Exception) {
            abortAllCalls()
            send(SpeedProgressUpdate(phase = SpeedPhase.ERROR, errorMessage = e.message ?: "SPEED_TEST_ERROR"))
        } finally {
            abortAllCalls()
        }
    }

    private data class TransferResult(val mbps: Double, val bytes: Long)

    private suspend fun runTransferPhase(
        isDownload: Boolean,
        streamCount: Int,
        warmUpMs: Long,
        measureMs: Long,
        activeCalls: MutableList<Call>,
        onTick: (inWarmUp: Boolean, instantMbps: Double, steadyMbps: Double, phaseProgress: Float, totalBytes: Long) -> Unit
    ): TransferResult = coroutineScope {
        val totalBytes = AtomicLong(0L)
        val measuredBytes = AtomicLong(0L)
        @Volatile var warmUpEnded = false

        val totalDurationMs = warmUpMs + measureMs
        val startNs = System.nanoTime()
        var steadyStartNs = 0L

        val workers = List(streamCount) {
            launch(Dispatchers.IO) {
                while (isActive) {
                    if (isDownload) {
                        executeDownloadChunk(activeCalls) { chunkBytes ->
                            totalBytes.addAndGet(chunkBytes)
                            if (warmUpEnded) measuredBytes.addAndGet(chunkBytes)
                        }
                    } else {
                        executeUploadChunk(activeCalls) { chunkBytes ->
                            totalBytes.addAndGet(chunkBytes)
                            if (warmUpEnded) measuredBytes.addAndGet(chunkBytes)
                        }
                    }
                }
            }
        }

        val ticker: Job = launch(Dispatchers.Default) {
            var lastBytes = 0L
            var lastTimeNs = startNs
            while (isActive) {
                delay(150L)
                val nowNs = System.nanoTime()
                val elapsedMs = (nowNs - startNs) / 1_000_000L
                if (!warmUpEnded && elapsedMs >= warmUpMs) {
                    warmUpEnded = true
                    steadyStartNs = nowNs
                }
                val currentTotal = totalBytes.get()
                val deltaBytes = (currentTotal - lastBytes).coerceAtLeast(0L)
                val deltaSec = ((nowNs - lastTimeNs) / 1_000_000_000.0).coerceAtLeast(0.05)
                val instantMbps = (deltaBytes * 8.0) / (deltaSec * 1_000_000.0)

                val steadyMbps = if (warmUpEnded && steadyStartNs > 0L) {
                    val steadySec = ((nowNs - steadyStartNs) / 1_000_000_000.0).coerceAtLeast(0.05)
                    (measuredBytes.get() * 8.0) / (steadySec * 1_000_000.0)
                } else {
                    instantMbps
                }

                val progress = (elapsedMs.toFloat() / totalDurationMs.toFloat()).coerceIn(0f, 1f)
                onTick(!warmUpEnded, instantMbps, steadyMbps, progress, currentTotal)

                lastBytes = currentTotal
                lastTimeNs = nowNs

                if (elapsedMs >= totalDurationMs) break
            }
        }

        ticker.join()
        workers.forEach { it.cancel() }
        synchronized(activeCalls) {
            activeCalls.forEach { runCatching { it.cancel() } }
            activeCalls.clear()
        }

        val finalSteadySec = if (steadyStartNs > 0L) {
            ((System.nanoTime() - steadyStartNs) / 1_000_000_000.0).coerceAtLeast(0.1)
        } else {
            (measureMs / 1000.0).coerceAtLeast(0.1)
        }
        val finalMbps = (measuredBytes.get() * 8.0) / (finalSteadySec * 1_000_000.0)
        TransferResult(mbps = finalMbps, bytes = totalBytes.get())
    }

    private fun executeDownloadChunk(
        activeCalls: MutableList<Call>,
        onBytes: (Long) -> Unit
    ) {
        val url = "https://speed.cloudflare.com/__down?bytes=15000000&nocache=${System.nanoTime()}"
        val request = Request.Builder()
            .url(url)
            .header("Cache-Control", "no-store")
            .get()
            .build()
        val call = speedClient.newCall(request)
        activeCalls.add(call)
        try {
            call.execute().use { response ->
                val stream = response.body?.byteStream() ?: return
                val buffer = ByteArray(32 * 1024)
                while (!call.isCanceled()) {
                    val read = stream.read(buffer)
                    if (read <= 0) break
                    onBytes(read.toLong())
                }
            }
        } catch (_: Exception) {
            // Expected on instant cancellation or socket reset
        } finally {
            activeCalls.remove(call)
        }
    }

    private fun executeUploadChunk(
        activeCalls: MutableList<Call>,
        onBytes: (Long) -> Unit
    ) {
        val payloadSize = 4 * 1024 * 1024L
        val chunk = ByteArray(32 * 1024) { (it % 251).toByte() }
        val body = object : RequestBody() {
            override fun contentType() = "application/octet-stream".toMediaType()
            override fun contentLength() = payloadSize
            override fun writeTo(sink: BufferedSink) {
                var remaining = payloadSize
                while (remaining > 0L) {
                    val toWrite = minOf(remaining, chunk.size.toLong()).toInt()
                    sink.write(chunk, 0, toWrite)
                    onBytes(toWrite.toLong())
                    remaining -= toWrite
                }
            }
        }
        val request = Request.Builder()
            .url("https://speed.cloudflare.com/__up")
            .post(body)
            .build()
        val call = speedClient.newCall(request)
        activeCalls.add(call)
        try {
            call.execute().close()
        } catch (_: Exception) {
            // Expected on instant cancellation
        } finally {
            activeCalls.remove(call)
        }
    }
}
