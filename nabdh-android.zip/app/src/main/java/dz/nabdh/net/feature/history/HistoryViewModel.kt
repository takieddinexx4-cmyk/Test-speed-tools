package dz.nabdh.net.feature.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dz.nabdh.net.data.local.MeasurementDao
import dz.nabdh.net.data.local.MeasurementEntity
import dz.nabdh.net.data.preferences.SettingsRepository
import dz.nabdh.net.data.preferences.UserSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HistoryViewModel @Inject constructor(
    private val measurementDao: MeasurementDao,
    settingsRepository: SettingsRepository
) : ViewModel() {

    val allMeasurements: StateFlow<List<MeasurementEntity>> = measurementDao.observeAll().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val weeklyMeasurements: StateFlow<List<MeasurementEntity>> = measurementDao
        .observeSince(System.currentTimeMillis() - 7L * 24L * 60L * 60L * 1000L)
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val settings: StateFlow<UserSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettings()
    )

    fun clearAll() {
        viewModelScope.launch { measurementDao.clearAll() }
    }
}
