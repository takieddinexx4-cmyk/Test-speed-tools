package dz.nabdh.net.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [MeasurementEntity::class],
    version = 1,
    exportSchema = false
)
abstract class NabdhDatabase : RoomDatabase() {
    abstract fun measurementDao(): MeasurementDao
}
