package dz.nabdh.net.feature.gaming.data

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import dz.nabdh.net.core.network.PingEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton

@Singleton
class GamingRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    @Named("probeClient") private val httpClient: OkHttpClient,
    private val json: Json,
    private val pingEngine: PingEngine
) {
    private val cacheFile: File
        get() = File(context.filesDir, "game_servers_cache.json")

    suspend fun loadCatalog(remoteUrl: String? = null, forceRefresh: Boolean = false): GameServersCatalog =
        withContext(Dispatchers.IO) {
            if (forceRefresh && !remoteUrl.isNullOrBlank()) {
                val remote = fetchRemoteCatalog(remoteUrl)
                if (remote != null) return@withContext remote
            }

            if (cacheFile.exists()) {
                val cached = runCatching {
                    json.decodeFromString<GameServersCatalog>(cacheFile.readText())
                }.getOrNull()
                if (cached != null && cached.games.isNotEmpty()) {
                    return@withContext cached
                }
            }

            // Default bundled catalog in assets/game_servers.json
            val assetText = context.assets.open("game_servers.json").bufferedReader().use { it.readText() }
            json.decodeFromString<GameServersCatalog>(assetText)
        }

    private fun fetchRemoteCatalog(url: String): GameServersCatalog? {
        return runCatching {
            val req = Request.Builder().url(url).get().build()
            httpClient.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@use null
                val body = resp.body?.string().orEmpty()
                val parsed = json.decodeFromString<GameServersCatalog>(body)
                if (parsed.games.isNotEmpty()) {
                    cacheFile.writeText(body)
                    parsed
                } else {
                    null
                }
            }
        }.getOrNull()
    }

    suspend fun benchmarkGame(game: GameProfile): List<RegionPingResult> = coroutineScope {
        game.regions.map { region ->
            async(Dispatchers.IO) {
                val stats = pingEngine.measurePing(
                    host = region.host,
                    port = region.port,
                    count = 6,
                    intervalMs = 150L,
                    timeoutMs = 1500
                )
                RegionPingResult(
                    region = region,
                    stats = stats,
                    verdict = GamingVerdictEvaluator.evaluate(stats)
                )
            }
        }.awaitAll().sortedWith(
            compareBy<RegionPingResult> { !it.stats.isReachable }
                .thenBy { it.stats.avgMs }
        )
    }
}
