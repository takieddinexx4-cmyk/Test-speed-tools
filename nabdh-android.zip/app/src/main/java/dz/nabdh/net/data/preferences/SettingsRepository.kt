package dz.nabdh.net.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.nabdhDataStore: DataStore<Preferences> by preferencesDataStore(name = "nabdh_settings")

enum class AppThemeMode { SYSTEM, DARK, LIGHT }
enum class SpeedUnit { MBPS, MB_PER_SEC }

data class UserSettings(
    val languageTag: String = "ar", // "ar", "fr", "en"
    val themeMode: AppThemeMode = AppThemeMode.DARK,
    val speedUnit: SpeedUnit = SpeedUnit.MBPS,
    val onboardingDone: Boolean = false,
    val speedConnections: Int = 6,
    val pingAlertEnabled: Boolean = false,
    val pingAlertThresholdMs: Int = 120,
    val pingAlertIntervalMinutes: Int = 30,
    val remoteGameServersUrl: String = ""
)

@Singleton
class SettingsRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private object Keys {
        val LANGUAGE = stringPreferencesKey("language_tag")
        val THEME = stringPreferencesKey("theme_mode")
        val UNIT = stringPreferencesKey("speed_unit")
        val ONBOARDING = booleanPreferencesKey("onboarding_done")
        val CONNECTIONS = intPreferencesKey("speed_connections")
        val ALERT_ENABLED = booleanPreferencesKey("ping_alert_enabled")
        val ALERT_THRESHOLD = intPreferencesKey("ping_alert_threshold_ms")
        val ALERT_INTERVAL = intPreferencesKey("ping_alert_interval_min")
        val REMOTE_GAMES_URL = stringPreferencesKey("remote_games_url")
    }

    val settingsFlow: Flow<UserSettings> = context.nabdhDataStore.data.map { prefs ->
        UserSettings(
            languageTag = prefs[Keys.LANGUAGE] ?: "ar",
            themeMode = runCatching {
                AppThemeMode.valueOf(prefs[Keys.THEME] ?: AppThemeMode.DARK.name)
            }.getOrDefault(AppThemeMode.DARK),
            speedUnit = runCatching {
                SpeedUnit.valueOf(prefs[Keys.UNIT] ?: SpeedUnit.MBPS.name)
            }.getOrDefault(SpeedUnit.MBPS),
            onboardingDone = prefs[Keys.ONBOARDING] ?: false,
            speedConnections = (prefs[Keys.CONNECTIONS] ?: 6).coerceIn(4, 8),
            pingAlertEnabled = prefs[Keys.ALERT_ENABLED] ?: false,
            pingAlertThresholdMs = (prefs[Keys.ALERT_THRESHOLD] ?: 120).coerceIn(40, 400),
            pingAlertIntervalMinutes = (prefs[Keys.ALERT_INTERVAL] ?: 30).coerceIn(15, 180),
            remoteGameServersUrl = prefs[Keys.REMOTE_GAMES_URL] ?: ""
        )
    }

    suspend fun setLanguage(tag: String) {
        context.nabdhDataStore.edit { it[Keys.LANGUAGE] = tag }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.nabdhDataStore.edit { it[Keys.THEME] = mode.name }
    }

    suspend fun setSpeedUnit(unit: SpeedUnit) {
        context.nabdhDataStore.edit { it[Keys.UNIT] = unit.name }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.nabdhDataStore.edit { it[Keys.ONBOARDING] = done }
    }

    suspend fun setSpeedConnections(count: Int) {
        context.nabdhDataStore.edit { it[Keys.CONNECTIONS] = count.coerceIn(4, 8) }
    }

    suspend fun setPingAlert(enabled: Boolean, thresholdMs: Int, intervalMinutes: Int) {
        context.nabdhDataStore.edit {
            it[Keys.ALERT_ENABLED] = enabled
            it[Keys.ALERT_THRESHOLD] = thresholdMs.coerceIn(40, 400)
            it[Keys.ALERT_INTERVAL] = intervalMinutes.coerceIn(15, 180)
        }
    }

    suspend fun setRemoteGameServersUrl(url: String) {
        context.nabdhDataStore.edit { it[Keys.REMOTE_GAMES_URL] = url.trim() }
    }
}
