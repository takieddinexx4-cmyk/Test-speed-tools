package dz.nabdh.net.feature.settings

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dz.nabdh.net.core.worker.PingAlertScheduler
import dz.nabdh.net.data.preferences.AppThemeMode
import dz.nabdh.net.data.preferences.SettingsRepository
import dz.nabdh.net.data.preferences.SpeedUnit
import dz.nabdh.net.data.preferences.UserSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository,
    private val alertScheduler: PingAlertScheduler
) : ViewModel() {

    val settings: StateFlow<UserSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettings()
    )

    fun setLanguage(tag: String) {
        viewModelScope.launch {
            settingsRepository.setLanguage(tag)
            AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
        }
    }

    fun setTheme(mode: AppThemeMode) {
        viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    }

    fun setSpeedUnit(unit: SpeedUnit) {
        viewModelScope.launch { settingsRepository.setSpeedUnit(unit) }
    }

    fun setSpeedConnections(count: Int) {
        viewModelScope.launch { settingsRepository.setSpeedConnections(count) }
    }

    fun updatePingAlert(enabled: Boolean, thresholdMs: Int, intervalMin: Int) {
        viewModelScope.launch {
            settingsRepository.setPingAlert(enabled, thresholdMs, intervalMin)
            alertScheduler.syncSchedule(enabled, intervalMin)
        }
    }

    fun setRemoteGamesUrl(url: String) {
        viewModelScope.launch { settingsRepository.setRemoteGameServersUrl(url) }
    }
}
