package dz.nabdh.net.core.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import javax.inject.Inject
import javax.inject.Singleton

data class SinglePingProbe(
    val sequence: Int,
    val rttMs: Double?,
    val timestampMs: Long = System.currentTimeMillis()
) {
    val succeeded: Boolean get() = rttMs != null
}

@Singleton
class PingEngine @Inject constructor() {

    /**
     * Measures real TCP handshake RTT to [host]:[port] in milliseconds using high-resolution nanoTime.
     * Returns null on timeout or unreachable host (representing a lost packet).
     */
    suspend fun probeOnce(
        host: String,
        port: Int = 443,
        timeoutMs: Int = 1500
    ): Double? = withContext(Dispatchers.IO) {
        val socket = Socket()
        try {
            val startNs = System.nanoTime()
            socket.connect(InetSocketAddress(host, port), timeoutMs)
            val elapsedNs = System.nanoTime() - startNs
            elapsedNs / 1_000_000.0
        } catch (_: Exception) {
            null
        } finally {
            runCatching { socket.close() }
        }
    }

    /**
     * Runs [count] sequential ping probes with [intervalMs] delay between probes.
     */
    suspend fun measurePing(
        host: String = "1.1.1.1",
        port: Int = 443,
        count: Int = 8,
        intervalMs: Long = 200L,
        timeoutMs: Int = 1500,
        onProbe: (SinglePingProbe) -> Unit = {}
    ): PingStats {
        val successfulSamples = mutableListOf<Double>()
        var sent = 0
        for (i in 1..count) {
            if (!currentCoroutineContext().isActive) break
            sent++
            val rtt = probeOnce(host, port, timeoutMs)
            if (rtt != null) {
                successfulSamples.add(rtt)
            }
            onProbe(SinglePingProbe(sequence = i, rttMs = rtt))
            if (i < count && intervalMs > 0L) {
                delay(intervalMs)
            }
        }
        return NetworkStatsCalculator.calculate(successfulSamples, sent)
    }
}
