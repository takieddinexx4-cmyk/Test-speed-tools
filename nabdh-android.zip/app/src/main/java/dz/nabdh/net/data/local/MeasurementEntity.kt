package dz.nabdh.net.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "measurements")
data class MeasurementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val timestampMs: Long = System.currentTimeMillis(),
    val type: String, // "SPEED", "STABILITY", "GAMING"
    val networkType: String,
    val isp: String?,
    val downloadMbps: Double,
    val uploadMbps: Double,
    val pingMs: Double,
    val jitterMs: Double,
    val packetLossPercent: Double,
    val verdict: String,
    val note: String? = null
)
