package dz.nabdh.net

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.stringResource
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.AndroidEntryPoint
import dz.nabdh.net.data.preferences.AppThemeMode
import dz.nabdh.net.data.preferences.SettingsRepository
import dz.nabdh.net.data.preferences.UserSettings
import dz.nabdh.net.feature.gaming.GamingScreen
import dz.nabdh.net.feature.history.HistoryScreen
import dz.nabdh.net.feature.settings.SettingsScreen
import dz.nabdh.net.feature.speed.SpeedTestScreen
import dz.nabdh.net.feature.stability.StabilityScreen
import dz.nabdh.net.ui.components.NabdhMeshBackground
import dz.nabdh.net.ui.onboarding.OnboardingScreen
import dz.nabdh.net.ui.theme.LocalGlassColors
import dz.nabdh.net.ui.theme.NabdhTheme
import kotlinx.coroutines.launch
import javax.inject.Inject

private data class NavDestination(
    val route: String,
    val labelRes: Int,
    val icon: ImageVector
)

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    @Inject lateinit var settingsRepository: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val settings by settingsRepository.settingsFlow.collectAsStateWithLifecycle(initialValue = UserSettings())
            val darkTheme = when (settings.themeMode) {
                AppThemeMode.DARK -> true
                AppThemeMode.LIGHT -> false
                AppThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            val scope = rememberCoroutineScope()

            NabdhTheme(
                darkTheme = darkTheme,
                isArabic = settings.languageTag == "ar"
            ) {
                NabdhMeshBackground {
                    if (!settings.onboardingDone) {
                        OnboardingScreen(
                            onFinished = {
                                scope.launch { settingsRepository.setOnboardingDone(true) }
                            }
                        )
                    } else {
                        NabdhMainShell()
                    }
                }
            }
        }
    }
}

@Composable
private fun NabdhMainShell() {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: "speed"
    val haptic = LocalHapticFeedback.current
    val glass = LocalGlassColors.current

    val destinations = listOf(
        NavDestination("speed", R.string.nav_speed, Icons.Rounded.Speed),
        NavDestination("stability", R.string.nav_stability, Icons.Rounded.Timeline),
        NavDestination("gaming", R.string.nav_gaming, Icons.Rounded.SportsEsports),
        NavDestination("history", R.string.nav_history, Icons.Rounded.History),
        NavDestination("settings", R.string.nav_settings, Icons.Rounded.Settings)
    )

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            NavigationBar(
                containerColor = glass.surfaceElevated
            ) {
                destinations.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route,
                        onClick = {
                            if (currentRoute != dest.route) {
                                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                navController.navigate(dest.route) {
                                    popUpTo("speed") { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = { Icon(dest.icon, contentDescription = stringResource(dest.labelRes)) },
                        label = { Text(stringResource(dest.labelRes), maxLines = 1) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .statusBarsPadding()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = "speed",
                enterTransition = { fadeIn() + slideInHorizontally { it / 12 } },
                exitTransition = { fadeOut() + slideOutHorizontally { -it / 12 } }
            ) {
                composable("speed") { SpeedTestScreen() }
                composable("stability") { StabilityScreen() }
                composable("gaming") { GamingScreen() }
                composable("history") { HistoryScreen() }
                composable("settings") { SettingsScreen() }
            }
        }
    }
}
