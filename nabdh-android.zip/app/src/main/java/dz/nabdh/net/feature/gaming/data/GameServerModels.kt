package dz.nabdh.net.feature.gaming.data

import dz.nabdh.net.core.network.PingStats
import kotlinx.serialization.Serializable

@Serializable
data class GameServersCatalog(
    val version: Int = 1,
    val updatedAt: String = "",
    val games: List<GameProfile> = emptyList()
)

@Serializable
data class GameProfile(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val nameFr: String,
    val regions: List<GameRegion>
) {
    fun localizedName(lang: String): String = when (lang) {
        "fr" -> nameFr
        "en" -> nameEn
        else -> nameAr
    }
}

@Serializable
data class GameRegion(
    val id: String,
    val nameAr: String,
    val nameEn: String,
    val nameFr: String,
    val host: String,
    val port: Int = 443
) {
    fun localizedName(lang: String): String = when (lang) {
        "fr" -> nameFr
        "en" -> nameEn
        else -> nameAr
    }
}

enum class GamingVerdict {
    READY, ACCEPTABLE, POOR
}

data class RegionPingResult(
    val region: GameRegion,
    val stats: PingStats,
    val verdict: GamingVerdict
)

object GamingVerdictEvaluator {
    fun evaluate(stats: PingStats): GamingVerdict {
        if (!stats.isReachable) return GamingVerdict.POOR
        if (stats.packetLossPercent >= 3.0 || stats.avgMs >= 120.0 || stats.jitterMs >= 25.0) {
            return GamingVerdict.POOR
        }
        if (stats.avgMs <= 65.0 && stats.jitterMs <= 10.0 && stats.packetLossPercent < 1.0) {
            return GamingVerdict.READY
        }
        return GamingVerdict.ACCEPTABLE
    }
}
