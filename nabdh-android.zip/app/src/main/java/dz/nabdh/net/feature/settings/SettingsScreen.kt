package dz.nabdh.net.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dz.nabdh.net.R
import dz.nabdh.net.data.preferences.AppThemeMode
import dz.nabdh.net.data.preferences.SpeedUnit
import dz.nabdh.net.ui.components.GlassButton
import dz.nabdh.net.ui.components.GlassCard
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    var remoteUrlInput by remember(settings.remoteGameServersUrl) {
        mutableStateOf(settings.remoteGameServersUrl)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = stringResource(R.string.settings_title),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        // Language
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ar" to "العربية", "fr" to "Français", "en" to "English").forEach { (tag, label) ->
                        FilterChip(
                            selected = settings.languageTag == tag,
                            onClick = { viewModel.setLanguage(tag) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }

        // Theme & Speed Unit
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.themeMode == AppThemeMode.DARK,
                        onClick = { viewModel.setTheme(AppThemeMode.DARK) },
                        label = { Text(stringResource(R.string.settings_theme_dark)) }
                    )
                    FilterChip(
                        selected = settings.themeMode == AppThemeMode.LIGHT,
                        onClick = { viewModel.setTheme(AppThemeMode.LIGHT) },
                        label = { Text(stringResource(R.string.settings_theme_light)) }
                    )
                    FilterChip(
                        selected = settings.themeMode == AppThemeMode.SYSTEM,
                        onClick = { viewModel.setTheme(AppThemeMode.SYSTEM) },
                        label = { Text(stringResource(R.string.settings_theme_system)) }
                    )
                }

                Text(stringResource(R.string.settings_unit), style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = settings.speedUnit == SpeedUnit.MBPS,
                        onClick = { viewModel.setSpeedUnit(SpeedUnit.MBPS) },
                        label = { Text("Mbps") }
                    )
                    FilterChip(
                        selected = settings.speedUnit == SpeedUnit.MB_PER_SEC,
                        onClick = { viewModel.setSpeedUnit(SpeedUnit.MB_PER_SEC) },
                        label = { Text("MB/s") }
                    )
                }

                Text(
                    text = "${stringResource(R.string.settings_connections)}: ${settings.speedConnections}",
                    style = MaterialTheme.typography.titleMedium
                )
                Slider(
                    value = settings.speedConnections.toFloat(),
                    onValueChange = { viewModel.setSpeedConnections(it.roundToInt()) },
                    valueRange = 4f..8f,
                    steps = 3
                )
            }
        }

        // WorkManager Ping Alerts
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(stringResource(R.string.settings_alerts_title), style = MaterialTheme.typography.titleMedium)
                        Text(
                            stringResource(R.string.settings_alerts_desc),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = settings.pingAlertEnabled,
                        onCheckedChange = { enabled ->
                            viewModel.updatePingAlert(
                                enabled = enabled,
                                thresholdMs = settings.pingAlertThresholdMs,
                                intervalMin = settings.pingAlertIntervalMinutes
                            )
                        }
                    )
                }
                Text(
                    text = "${stringResource(R.string.settings_alert_threshold)}: ${settings.pingAlertThresholdMs} ms",
                    style = MaterialTheme.typography.bodyMedium
                )
                Slider(
                    value = settings.pingAlertThresholdMs.toFloat(),
                    onValueChange = {
                        viewModel.updatePingAlert(
                            enabled = settings.pingAlertEnabled,
                            thresholdMs = it.roundToInt(),
                            intervalMin = settings.pingAlertIntervalMinutes
                        )
                    },
                    valueRange = 50f..250f
                )
            }
        }

        // Remote Game Servers JSON URL
        GlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.settings_remote_json), style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(
                    value = remoteUrlInput,
                    onValueChange = { remoteUrlInput = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://.../game_servers.json") }
                )
                GlassButton(
                    text = stringResource(R.string.settings_save),
                    onClick = { viewModel.setRemoteGamesUrl(remoteUrlInput) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Spacer(modifier = Modifier.height(72.dp))
    }
}
