package dz.nabdh.net.feature.stability

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dz.nabdh.net.core.network.PacketLossTick
import dz.nabdh.net.core.network.StabilityEngine
import dz.nabdh.net.core.network.StabilityTick
import dz.nabdh.net.data.local.MeasurementDao
import dz.nabdh.net.data.local.MeasurementEntity
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject

data class StabilityUiState(
    val selectedDurationSec: Int = 30,
    val isRunningStability: Boolean = false,
    val isRunningPacketLoss: Boolean = false,
    val stabilityTick: StabilityTick? = null,
    val packetLossTick: PacketLossTick? = null
)

@HiltViewModel
class StabilityViewModel @Inject constructor(
    private val stabilityEngine: StabilityEngine,
    private val measurementDao: MeasurementDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(StabilityUiState())
    val uiState: StateFlow<StabilityUiState> = _uiState.asStateFlow()

    private var job: Job? = null

    fun selectDuration(seconds: Int) {
        if (_uiState.value.isRunningStability) return
        _uiState.update { it.copy(selectedDurationSec = seconds) }
    }

    fun startStability() {
        job?.cancel()
        val duration = _uiState.value.selectedDurationSec
        job = viewModelScope.launch {
            _uiState.update { it.copy(isRunningStability = true, isRunningPacketLoss = false) }
            stabilityEngine.runStabilitySession(durationSeconds = duration).collect { tick ->
                _uiState.update {
                    it.copy(
                        stabilityTick = tick,
                        isRunningStability = !tick.completed
                    )
                }
                if (tick.completed) {
                    val s = tick.evaluation.stats
                    measurementDao.insert(
                        MeasurementEntity(
                            type = "STABILITY",
                            networkType = "LIVE",
                            isp = null,
                            downloadMbps = 0.0,
                            uploadMbps = 0.0,
                            pingMs = s.avgMs,
                            jitterMs = s.jitterMs,
                            packetLossPercent = s.packetLossPercent,
                            verdict = tick.evaluation.verdict.name,
                            note = "${duration}s • σ=${String.format(Locale.US, "%.1f", s.stdDevMs)}ms"
                        )
                    )
                }
            }
        }
    }

    fun startPacketLoss100() {
        job?.cancel()
        job = viewModelScope.launch {
            _uiState.update { it.copy(isRunningPacketLoss = true, isRunningStability = false) }
            stabilityEngine.runPacketLoss100().collect { tick ->
                _uiState.update {
                    it.copy(
                        packetLossTick = tick,
                        isRunningPacketLoss = !tick.completed
                    )
                }
            }
        }
    }

    fun cancelActive() {
        job?.cancel()
        job = null
        _uiState.update { it.copy(isRunningStability = false, isRunningPacketLoss = false) }
    }
}
