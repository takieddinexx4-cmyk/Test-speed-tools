package dz.nabdh.net.feature.speed

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dz.nabdh.net.core.network.ConnectionRepository
import dz.nabdh.net.core.network.ConnectionSnapshot
import dz.nabdh.net.core.network.PingEngine
import dz.nabdh.net.core.network.PingStats
import dz.nabdh.net.core.network.SpeedPhase
import dz.nabdh.net.core.network.SpeedProgressUpdate
import dz.nabdh.net.core.network.SpeedTestEngine
import dz.nabdh.net.data.local.MeasurementDao
import dz.nabdh.net.data.local.MeasurementEntity
import dz.nabdh.net.data.preferences.SettingsRepository
import dz.nabdh.net.data.preferences.UserSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SpeedUiState(
    val connection: ConnectionSnapshot? = null,
    val isRefreshingConnection: Boolean = true,
    val quickPing: PingStats? = null,
    val speedUpdate: SpeedProgressUpdate = SpeedProgressUpdate(SpeedPhase.IDLE),
    val chartPoints: List<Double> = emptyList(),
    val isRunning: Boolean = false
)

@HiltViewModel
class SpeedTestViewModel @Inject constructor(
    private val connectionRepository: ConnectionRepository,
    private val pingEngine: PingEngine,
    private val speedTestEngine: SpeedTestEngine,
    private val measurementDao: MeasurementDao,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(SpeedUiState())
    val uiState: StateFlow<SpeedUiState> = _uiState.asStateFlow()

    val settings: StateFlow<UserSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettings()
    )

    private var activeTestJob: Job? = null

    init {
        refreshConnection()
    }

    fun refreshConnection() {
        viewModelScope.launch {
            _uiState.update { it.copy(isRefreshingConnection = true) }
            val snapshot = connectionRepository.inspectConnection()
            val ping = if (snapshot.isInternetReachable) {
                pingEngine.measurePing(host = "1.1.1.1", port = 443, count = 5, intervalMs = 150L)
            } else {
                null
            }
            _uiState.update {
                it.copy(
                    connection = snapshot,
                    quickPing = ping,
                    isRefreshingConnection = false
                )
            }
        }
    }

    fun startSpeedTest() {
        if (_uiState.value.isRunning) return
        activeTestJob?.cancel()
        activeTestJob = viewModelScope.launch {
            val currentSettings = settingsRepository.settingsFlow.first()
            _uiState.update {
                it.copy(
                    isRunning = true,
                    chartPoints = emptyList(),
                    speedUpdate = SpeedProgressUpdate(SpeedPhase.PING)
                )
            }
            try {
                speedTestEngine.runSpeedTest(connections = currentSettings.speedConnections).collect { update ->
                    _uiState.update { state ->
                        val nextChart = if (update.phase == SpeedPhase.DOWNLOAD || update.phase == SpeedPhase.UPLOAD) {
                            (state.chartPoints + update.currentMbps).takeLast(45)
                        } else {
                            state.chartPoints
                        }
                        state.copy(
                            speedUpdate = update,
                            chartPoints = nextChart,
                            isRunning = update.phase !in setOf(
                                SpeedPhase.COMPLETED,
                                SpeedPhase.CANCELLED,
                                SpeedPhase.ERROR,
                                SpeedPhase.IDLE
                            )
                        )
                    }
                    if (update.phase == SpeedPhase.COMPLETED) {
                        val conn = _uiState.value.connection
                        measurementDao.insert(
                            MeasurementEntity(
                                type = "SPEED",
                                networkType = conn?.networkType?.name ?: "UNKNOWN",
                                isp = conn?.isp,
                                downloadMbps = update.downloadMbps,
                                uploadMbps = update.uploadMbps,
                                pingMs = update.pingMs,
                                jitterMs = update.jitterMs,
                                packetLossPercent = 0.0,
                                verdict = if (update.downloadMbps >= 20.0) "GOOD" else "MODERATE"
                            )
                        )
                    }
                }
            } catch (_: CancellationException) {
                _uiState.update {
                    it.copy(
                        isRunning = false,
                        speedUpdate = it.speedUpdate.copy(phase = SpeedPhase.CANCELLED, currentMbps = 0.0)
                    )
                }
            }
        }
    }

    fun cancelSpeedTest() {
        activeTestJob?.cancel()
        activeTestJob = null
        _uiState.update {
            it.copy(
                isRunning = false,
                speedUpdate = it.speedUpdate.copy(phase = SpeedPhase.CANCELLED, currentMbps = 0.0)
            )
        }
    }
}
