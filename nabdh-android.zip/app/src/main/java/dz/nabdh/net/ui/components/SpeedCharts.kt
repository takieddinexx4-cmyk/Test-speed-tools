package dz.nabdh.net.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dz.nabdh.net.data.preferences.SpeedUnit
import dz.nabdh.net.ui.theme.NabdhCyan
import dz.nabdh.net.ui.theme.NabdhDeepBlue
import dz.nabdh.net.ui.theme.NabdhTurquoise
import java.util.Locale
import kotlin.math.max

fun formatSpeed(mbps: Double, unit: SpeedUnit): String {
    return when (unit) {
        SpeedUnit.MBPS -> String.format(Locale.US, "%.1f Mbps", mbps)
        SpeedUnit.MB_PER_SEC -> String.format(Locale.US, "%.2f MB/s", mbps / 8.0)
    }
}

fun formatSpeedNumber(mbps: Double, unit: SpeedUnit): String {
    return when (unit) {
        SpeedUnit.MBPS -> String.format(Locale.US, "%.1f", mbps)
        SpeedUnit.MB_PER_SEC -> String.format(Locale.US, "%.2f", mbps / 8.0)
    }
}

fun unitLabel(unit: SpeedUnit): String = if (unit == SpeedUnit.MBPS) "Mbps" else "MB/s"

@Composable
fun AnimatedSpeedGauge(
    speedMbps: Double,
    unit: SpeedUnit,
    phaseLabel: String,
    modifier: Modifier = Modifier
) {
    // Non-linear scale up to 300 Mbps so typical 10-100 Mbps Algerian lines look expressive
    val normalizedTarget = (speedMbps / 150.0).coerceIn(0.0, 1.0).toFloat()
    val animatedSweep by animateFloatAsState(
        targetValue = normalizedTarget * 260f,
        animationSpec = tween(durationMillis = 220),
        label = "gauge_sweep"
    )
    val trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)

    Box(
        modifier = modifier
            .size(220.dp)
            .semantics { contentDescription = "$phaseLabel ${formatSpeed(speedMbps, unit)}" },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 18.dp.toPx()
            val inset = strokeWidth / 2f + 8.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)

            drawArc(
                color = trackColor,
                startAngle = 140f,
                sweepAngle = 260f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(NabdhDeepBlue, NabdhCyan, NabdhTurquoise, NabdhCyan)),
                startAngle = 140f,
                sweepAngle = animatedSweep.coerceAtLeast(3f),
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = formatSpeedNumber(speedMbps, unit),
                style = MaterialTheme.typography.displayLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = unitLabel(unit),
                style = MaterialTheme.typography.titleMedium,
                color = NabdhCyan
            )
            Text(
                text = phaseLabel,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun LiveMetricLineChart(
    points: List<Double>,
    lineColor: Color = NabdhCyan,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(110.dp)
    ) {
        if (points.size < 2) return@Canvas
        val maxVal = max(points.maxOrNull() ?: 1.0, 1.0)
        val minVal = (points.minOrNull() ?: 0.0).coerceAtMost(maxVal * 0.8)
        val range = max(maxVal - minVal, 1.0)
        val stepX = size.width / (points.size - 1).coerceAtLeast(1)

        val linePath = Path()
        val fillPath = Path()

        points.forEachIndexed { index, value ->
            val x = index * stepX
            val ratio = ((value - minVal) / range).toFloat().coerceIn(0f, 1f)
            val y = size.height - (ratio * (size.height - 16f)) - 8f
            if (index == 0) {
                linePath.moveTo(x, y)
                fillPath.moveTo(x, size.height)
                fillPath.lineTo(x, y)
            } else {
                linePath.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
            if (index == points.lastIndex) {
                fillPath.lineTo(x, size.height)
                fillPath.close()
            }
        }

        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(lineColor.copy(alpha = 0.30f), Color.Transparent)
            )
        )
        drawPath(
            path = linePath,
            color = lineColor,
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}
