package dz.nabdh.net.core.network

import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.isActive
import javax.inject.Inject
import javax.inject.Singleton

data class StabilityTick(
    val elapsedSeconds: Int,
    val totalSeconds: Int,
    val samples: List<SinglePingProbe>,
    val evaluation: StabilityEvaluation,
    val completed: Boolean
)

data class PacketLossTick(
    val sent: Int,
    val received: Int,
    val lost: Int,
    val lossPercent: Double,
    val avgMs: Double,
    val completed: Boolean
)

@Singleton
class StabilityEngine @Inject constructor(
    private val pingEngine: PingEngine
) {

    /**
     * Runs a continuous stability session for [durationSeconds] (30, 60, or 120) sampling every 500ms.
     */
    fun runStabilitySession(
        host: String = "1.1.1.1",
        port: Int = 443,
        durationSeconds: Int = 30
    ): Flow<StabilityTick> = flow {
        val totalProbes = (durationSeconds * 2).coerceAtLeast(10)
        val probes = mutableListOf<SinglePingProbe>()
        val rtts = mutableListOf<Double>()

        for (seq in 1..totalProbes) {
            if (!currentCoroutineContext().isActive) break
            val start = System.currentTimeMillis()
            val rtt = pingEngine.probeOnce(host = host, port = port, timeoutMs = 1200)
            val probe = SinglePingProbe(sequence = seq, rttMs = rtt)
            probes.add(probe)
            if (rtt != null) rtts.add(rtt)

            val evaluation = StabilityAnalyzer.evaluate(rtts, totalSent = seq)
            emit(
                StabilityTick(
                    elapsedSeconds = (seq / 2).coerceAtMost(durationSeconds),
                    totalSeconds = durationSeconds,
                    samples = probes.toList(),
                    evaluation = evaluation,
                    completed = seq == totalProbes
                )
            )

            val elapsed = System.currentTimeMillis() - start
            val wait = (500L - elapsed).coerceAtLeast(20L)
            if (seq < totalProbes) delay(wait)
        }
    }

    /**
     * Sends exactly 100 real probes to compute accurate packet loss percentage.
     */
    fun runPacketLoss100(
        host: String = "1.1.1.1",
        port: Int = 443
    ): Flow<PacketLossTick> = flow {
        val total = 100
        val rtts = mutableListOf<Double>()
        var received = 0
        for (i in 1..total) {
            if (!currentCoroutineContext().isActive) break
            val rtt = pingEngine.probeOnce(host = host, port = port, timeoutMs = 1000)
            if (rtt != null) {
                received++
                rtts.add(rtt)
            }
            val lost = i - received
            val lossPct = (lost.toDouble() / i.toDouble()) * 100.0
            emit(
                PacketLossTick(
                    sent = i,
                    received = received,
                    lost = lost,
                    lossPercent = lossPct,
                    avgMs = if (rtts.isEmpty()) 0.0 else rtts.average(),
                    completed = i == total
                )
            )
            if (i < total) delay(80L)
        }
    }
}
