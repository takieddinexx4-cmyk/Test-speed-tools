package dz.nabdh.net.feature.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dz.nabdh.net.R
import dz.nabdh.net.core.share.ResultImageSharer
import dz.nabdh.net.core.share.ShareableResult
import dz.nabdh.net.ui.components.GlassCard
import dz.nabdh.net.ui.components.LiveMetricLineChart
import dz.nabdh.net.ui.components.formatSpeed
import dz.nabdh.net.ui.theme.NabdhCyan
import dz.nabdh.net.ui.theme.NabdhTurquoise
import dz.nabdh.net.ui.theme.StatusBad
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    viewModel: HistoryViewModel = hiltViewModel()
) {
    val items by viewModel.allMeasurements.collectAsStateWithLifecycle()
    val weekly by viewModel.weeklyMeasurements.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val dateFmt = SimpleDateFormat("dd/MM HH:mm", Locale.US)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = stringResource(R.string.history_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            if (items.isNotEmpty()) {
                IconButton(onClick = { viewModel.clearAll() }) {
                    Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = stringResource(R.string.history_clear),
                        tint = StatusBad
                    )
                }
            }
        }

        // Weekly Chart
        val weeklySpeeds = weekly.filter { it.downloadMbps > 0.0 }.map { it.downloadMbps }
        val weeklyPings = weekly.filter { it.pingMs > 0.0 }.map { it.pingMs }
        if (weeklySpeeds.size >= 2 || weeklyPings.size >= 2) {
            GlassCard(modifier = Modifier.fillMaxWidth(), elevated = true) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.history_weekly_chart),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (weeklySpeeds.size >= 2) {
                        Text(
                            text = stringResource(R.string.label_download),
                            style = MaterialTheme.typography.labelSmall,
                            color = NabdhCyan
                        )
                        LiveMetricLineChart(points = weeklySpeeds, lineColor = NabdhCyan)
                    }
                    if (weeklyPings.size >= 2) {
                        Text(
                            text = stringResource(R.string.label_ping),
                            style = MaterialTheme.typography.labelSmall,
                            color = NabdhTurquoise
                        )
                        LiveMetricLineChart(points = weeklyPings, lineColor = NabdhTurquoise)
                    }
                }
            }
        }

        if (items.isEmpty()) {
            GlassCard(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = stringResource(R.string.history_empty),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            items.forEach { item ->
                GlassCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "${item.type} • ${dateFmt.format(Date(item.timestampMs))}",
                                style = MaterialTheme.typography.labelLarge,
                                color = NabdhCyan
                            )
                            if (item.downloadMbps > 0.0 || item.uploadMbps > 0.0) {
                                Text(
                                    text = "↓ ${formatSpeed(item.downloadMbps, settings.speedUnit)}  ↑ ${formatSpeed(item.uploadMbps, settings.speedUnit)}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Text(
                                text = String.format(
                                    Locale.US,
                                    "Ping %.1f ms • Jitter %.1f ms • Loss %.1f%%",
                                    item.pingMs,
                                    item.jitterMs,
                                    item.packetLossPercent
                                ),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            ResultImageSharer.shareResultCard(
                                context = context,
                                result = ShareableResult(
                                    title = item.type,
                                    downloadLabel = formatSpeed(item.downloadMbps, settings.speedUnit),
                                    uploadLabel = formatSpeed(item.uploadMbps, settings.speedUnit),
                                    pingMs = item.pingMs,
                                    jitterMs = item.jitterMs,
                                    isp = item.isp,
                                    timestampMs = item.timestampMs
                                )
                            )
                        }) {
                            Icon(
                                imageVector = Icons.Rounded.Share,
                                contentDescription = stringResource(R.string.action_share_image),
                                tint = NabdhTurquoise
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(72.dp))
    }
}
