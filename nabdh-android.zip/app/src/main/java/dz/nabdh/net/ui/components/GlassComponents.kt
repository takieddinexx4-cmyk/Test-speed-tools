package dz.nabdh.net.ui.components

import android.os.Build
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dz.nabdh.net.ui.theme.DzEmerald
import dz.nabdh.net.ui.theme.LightBgBottom
import dz.nabdh.net.ui.theme.LightBgMid
import dz.nabdh.net.ui.theme.LightBgTop
import dz.nabdh.net.ui.theme.LocalGlassColors
import dz.nabdh.net.ui.theme.NabdhCyan
import dz.nabdh.net.ui.theme.NabdhDeepBlue
import dz.nabdh.net.ui.theme.NabdhMidnight
import dz.nabdh.net.ui.theme.NabdhNavy
import dz.nabdh.net.ui.theme.NabdhTurquoise
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

val GlassCardShape = RoundedCornerShape(28.dp)

/**
 * Animated Mesh Gradient Background adapting smoothly to Dark and Light themes.
 */
@Composable
fun NabdhMeshBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalGlassColors.current
    val transition = rememberInfiniteTransition(label = "mesh_bg")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "mesh_phase"
    )

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            val baseGradient = if (glass.isDark) {
                Brush.verticalGradient(listOf(NabdhMidnight, NabdhNavy, Color(0xFF061529)))
            } else {
                Brush.verticalGradient(listOf(LightBgTop, LightBgMid, LightBgBottom))
            }
            drawRect(brush = baseGradient)

            val c1 = Offset(
                x = w * (0.25f + 0.15f * cos(phase)),
                y = h * (0.20f + 0.10f * sin(phase))
            )
            val c2 = Offset(
                x = w * (0.80f + 0.12f * sin(phase * 0.8f)),
                y = h * (0.45f + 0.12f * cos(phase * 0.8f))
            )
            val c3 = Offset(
                x = w * (0.35f + 0.18f * cos(phase + 1.8f)),
                y = h * (0.82f + 0.08f * sin(phase + 1.8f))
            )

            val alphaScale = if (glass.isDark) 0.28f else 0.18f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NabdhCyan.copy(alpha = alphaScale), Color.Transparent),
                    center = c1,
                    radius = w * 0.72f
                ),
                center = c1,
                radius = w * 0.72f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(NabdhDeepBlue.copy(alpha = alphaScale * 1.1f), Color.Transparent),
                    center = c2,
                    radius = w * 0.78f
                ),
                center = c2,
                radius = w * 0.78f
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(DzEmerald.copy(alpha = alphaScale * 0.75f), Color.Transparent),
                    center = c3,
                    radius = w * 0.65f
                ),
                center = c3,
                radius = w * 0.65f
            )
        }
        content()
    }
}

/**
 * Glassmorphic 28.dp card with luminous gradient border.
 * Uses real RenderEffect blur on Android 12+ (API 31+) and a layered translucent glass fallback on API 26-30.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    elevated: Boolean = false,
    padding: PaddingValues = PaddingValues(18.dp),
    content: @Composable BoxScope.() -> Unit
) {
    val glass = LocalGlassColors.current
    val fillColor = if (elevated) glass.surfaceElevated else glass.surface
    val borderBrush = Brush.linearGradient(
        colors = listOf(glass.borderStart, glass.borderEnd, glass.borderStart.copy(alpha = 0.25f))
    )

    Box(
        modifier = modifier
            .clip(GlassCardShape)
            .border(width = 1.dp, brush = borderBrush, shape = GlassCardShape)
    ) {
        // Real blur backdrop layer on Android 12+, translucent glass sheen on older APIs
        val backdropModifier = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Modifier
                .matchParentSize()
                .background(fillColor)
                .blur(radius = 20.dp, edgeTreatment = BlurredEdgeTreatment.Rectangle)
        } else {
            Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            fillColor.copy(alpha = (fillColor.alpha + 0.16f).coerceAtMost(0.92f)),
                            fillColor.copy(alpha = (fillColor.alpha + 0.08f).coerceAtMost(0.86f))
                        )
                    )
                )
        }
        Box(modifier = backdropModifier)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding),
            content = content
        )
    }
}

/**
 * Spring-animated glass action button with haptic feedback.
 */
@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    accent: Color = NabdhCyan,
    enabled: Boolean = true
) {
    val haptic = LocalHapticFeedback.current
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "btn_scale"
    )
    val gradient = Brush.horizontalGradient(
        colors = if (enabled) listOf(accent, NabdhTurquoise) else listOf(Color.Gray.copy(alpha = 0.4f), Color.Gray.copy(alpha = 0.3f))
    )

    Box(
        modifier = modifier
            .scale(scale)
            .clip(RoundedCornerShape(22.dp))
            .background(gradient)
            .border(1.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(22.dp))
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                role = Role.Button
            ) {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onClick()
            }
            .semantics { contentDescription = text }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = NabdhMidnight,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
            }
            Text(
                text = text,
                style = MaterialTheme.typography.labelLarge,
                color = NabdhMidnight
            )
        }
    }
}

/**
 * Status pill badge with glowing dot.
 */
@Composable
fun StatusPill(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.16f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = color
        )
    }
}

/**
 * Smooth shimmer placeholder for loading states.
 */
@Composable
fun GlassShimmerBox(
    modifier: Modifier = Modifier,
    height: Dp = 20.dp
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val offset by transition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_x"
    )
    val glass = LocalGlassColors.current
    val base = if (glass.isDark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.07f)
    val highlight = if (glass.isDark) Color.White.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.65f)

    Box(
        modifier = modifier
            .height(height)
            .clip(RoundedCornerShape(12.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(base, highlight, base),
                    start = Offset(offset, 0f),
                    end = Offset(offset + 260f, 80f)
                )
            )
    )
}
