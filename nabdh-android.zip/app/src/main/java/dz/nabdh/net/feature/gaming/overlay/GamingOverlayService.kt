package dz.nabdh.net.feature.gaming.overlay

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import dagger.hilt.android.AndroidEntryPoint
import dz.nabdh.net.MainActivity
import dz.nabdh.net.R
import dz.nabdh.net.core.network.NetworkStatsCalculator
import dz.nabdh.net.core.network.PingEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import javax.inject.Inject
import kotlin.math.abs

@AndroidEntryPoint
class GamingOverlayService : Service() {

    @Inject lateinit var pingEngine: PingEngine

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null

    private var targetHost: String = "ec2.eu-central-1.amazonaws.com"
    private var targetPort: Int = 443
    private var serverLabel: String = "PUBG EU"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        targetHost = intent?.getStringExtra(EXTRA_HOST) ?: targetHost
        targetPort = intent?.getIntExtra(EXTRA_PORT, 443) ?: 443
        serverLabel = intent?.getStringExtra(EXTRA_LABEL) ?: serverLabel

        startForeground(NOTIFICATION_ID, buildNotification())
        if (overlayView == null) {
            attachFloatingPill()
            startLiveMonitoring()
        }
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachFloatingPill() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val density = resources.displayMetrics.density
        fun dp(value: Int): Int = (value * density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(24).toFloat()
                setColor(Color.parseColor("#DD0B162C"))
                setStroke(dp(1), Color.parseColor("#8800D4FF"))
            }
            elevation = dp(8).toFloat()
        }

        val statusDot = View(this).apply {
            tag = TAG_DOT
            layoutParams = LinearLayout.LayoutParams(dp(9), dp(9)).apply {
                marginEnd = dp(8)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#10E59B"))
            }
        }

        val metricsCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val pingText = TextView(this).apply {
            tag = TAG_PING
            text = "-- ms"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            paint.isFakeBoldText = true
        }

        val subText = TextView(this).apply {
            tag = TAG_SUB
            text = serverLabel
            setTextColor(Color.parseColor("#B0C4DE"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
        }

        metricsCol.addView(pingText)
        metricsCol.addView(subText)

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#E2E8F0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(dp(10), dp(2), dp(4), dp(2))
            contentDescription = getString(R.string.overlay_close)
            setOnClickListener { stopSelf() }
        }

        root.addView(statusDot)
        root.addView(metricsCol)
        root.addView(closeBtn)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(96)
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 2 || abs(dy) > 2) {
                        params.x = initialX + dx
                        params.y = initialY + dy
                        runCatching { wm.updateViewLayout(root, params) }
                    }
                    true
                }
                else -> false
            }
        }

        wm.addView(root, params)
        overlayView = root
    }

    private fun startLiveMonitoring() {
        val windowSamples = ArrayDeque<Double>()
        var sentCount = 0
        var lostCount = 0

        serviceScope.launch(Dispatchers.IO) {
            while (isActive) {
                sentCount++
                val rtt = pingEngine.probeOnce(host = targetHost, port = targetPort, timeoutMs = 1200)
                if (rtt != null) {
                    if (windowSamples.size >= 15) windowSamples.removeFirst()
                    windowSamples.addLast(rtt)
                } else {
                    lostCount++
                }
                val stats = NetworkStatsCalculator.calculate(windowSamples.toList(), totalSent = windowSamples.size)
                val lossPct = (lostCount.toDouble() / sentCount.toDouble()) * 100.0

                withContext(Dispatchers.Main) {
                    val root = overlayView ?: return@withContext
                    val pingTv = root.findViewWithTag<TextView>(TAG_PING)
                    val subTv = root.findViewWithTag<TextView>(TAG_SUB)
                    val dot = root.findViewWithTag<View>(TAG_DOT)

                    if (rtt == null) {
                        pingTv?.text = getString(R.string.overlay_timeout)
                        (dot?.background as? GradientDrawable)?.setColor(Color.parseColor("#FF4D6D"))
                    } else {
                        pingTv?.text = String.format(Locale.US, "%.0f ms", rtt)
                        val dotColor = when {
                            rtt <= 65.0 && stats.jitterMs <= 12.0 -> "#10E59B"
                            rtt <= 115.0 -> "#FFB547"
                            else -> "#FF4D6D"
                        }
                        (dot?.background as? GradientDrawable)?.setColor(Color.parseColor(dotColor))
                    }
                    subTv?.text = String.format(
                        Locale.US,
                        "%s • J %.0fms • L %.0f%%",
                        serverLabel,
                        stats.jitterMs,
                        lossPct
                    )
                }
                delay(1000L)
            }
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.overlay_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            nm.createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, GamingOverlayService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(getString(R.string.overlay_notif_title))
            .setContentText(getString(R.string.overlay_notif_body, serverLabel))
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.overlay_close), stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        serviceScope.cancel()
        overlayView?.let { view ->
            runCatching { windowManager?.removeViewImmediate(view) }
        }
        overlayView = null
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "nabdh_gaming_overlay"
        const val NOTIFICATION_ID = 7001
        const val ACTION_STOP = "dz.nabdh.net.ACTION_STOP_OVERLAY"
        const val EXTRA_HOST = "extra_host"
        const val EXTRA_PORT = "extra_port"
        const val EXTRA_LABEL = "extra_label"
        private const val TAG_DOT = "dot"
        private const val TAG_PING = "ping"
        private const val TAG_SUB = "sub"

        fun start(context: Context, host: String, port: Int, label: String) {
            val intent = Intent(context, GamingOverlayService::class.java).apply {
                putExtra(EXTRA_HOST, host)
                putExtra(EXTRA_PORT, port)
                putExtra(EXTRA_LABEL, label)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, GamingOverlayService::class.java))
        }
    }
}
