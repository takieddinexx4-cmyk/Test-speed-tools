package dz.nabdh.net.core.worker

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.hilt.work.HiltWorker
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import dz.nabdh.net.MainActivity
import dz.nabdh.net.R
import dz.nabdh.net.core.network.PingEngine
import dz.nabdh.net.data.preferences.SettingsRepository
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@HiltWorker
class PingMonitorWorker @AssistedInject constructor(
    @Assisted private val appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val pingEngine: PingEngine,
    private val settingsRepository: SettingsRepository
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val settings = settingsRepository.settingsFlow.first()
        if (!settings.pingAlertEnabled) return Result.success()

        val stats = pingEngine.measurePing(host = "1.1.1.1", port = 443, count = 4, intervalMs = 200L)
        if (!stats.isReachable) {
            postAlert(
                title = appContext.getString(R.string.alert_offline_title),
                body = appContext.getString(R.string.alert_offline_body)
            )
            return Result.success()
        }

        if (stats.avgMs >= settings.pingAlertThresholdMs) {
            postAlert(
                title = appContext.getString(R.string.alert_high_ping_title),
                body = appContext.getString(
                    R.string.alert_high_ping_body,
                    stats.avgMs.toInt(),
                    settings.pingAlertThresholdMs
                )
            )
        }
        return Result.success()
    }

    private fun postAlert(title: String, body: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                appContext,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val nm = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                ALERT_CHANNEL_ID,
                appContext.getString(R.string.alert_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            )
            nm.createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            appContext,
            0,
            Intent(appContext, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(appContext, ALERT_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(openIntent)
            .build()

        nm.notify(ALERT_NOTIFICATION_ID, notification)
    }

    companion object {
        const val WORK_NAME = "nabdh_ping_monitor_periodic"
        const val ALERT_CHANNEL_ID = "nabdh_ping_alerts"
        const val ALERT_NOTIFICATION_ID = 7002
    }
}

@Singleton
class PingAlertScheduler @Inject constructor(
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context
) {
    fun syncSchedule(enabled: Boolean, intervalMinutes: Int) {
        val wm = WorkManager.getInstance(context)
        if (!enabled) {
            wm.cancelUniqueWork(PingMonitorWorker.WORK_NAME)
            return
        }
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<PingMonitorWorker>(
            intervalMinutes.coerceAtLeast(15).toLong(),
            TimeUnit.MINUTES
        ).setConstraints(constraints).build()

        wm.enqueueUniquePeriodicWork(
            PingMonitorWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }
}
