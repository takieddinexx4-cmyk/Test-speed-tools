package dz.nabdh.net.feature.gaming

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dz.nabdh.net.data.local.MeasurementDao
import dz.nabdh.net.data.local.MeasurementEntity
import dz.nabdh.net.data.preferences.SettingsRepository
import dz.nabdh.net.data.preferences.UserSettings
import dz.nabdh.net.feature.gaming.data.GameProfile
import dz.nabdh.net.feature.gaming.data.GamingRepository
import dz.nabdh.net.feature.gaming.data.RegionPingResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

data class GamingUiState(
    val games: List<GameProfile> = emptyList(),
    val selectedGame: GameProfile? = null,
    val results: List<RegionPingResult> = emptyList(),
    val isScanning: Boolean = false,
    val overlayRunning: Boolean = false
)

@HiltViewModel
class GamingViewModel @Inject constructor(
    private val gamingRepository: GamingRepository,
    private val settingsRepository: SettingsRepository,
    private val measurementDao: MeasurementDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(GamingUiState())
    val uiState: StateFlow<GamingUiState> = _uiState.asStateFlow()

    val settings: StateFlow<UserSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = UserSettings()
    )

    init {
        loadGames(forceRefresh = false)
    }

    fun loadGames(forceRefresh: Boolean) {
        viewModelScope.launch {
            val remoteUrl = settingsRepository.settingsFlow.first().remoteGameServersUrl
            val catalog = gamingRepository.loadCatalog(remoteUrl = remoteUrl, forceRefresh = forceRefresh)
            _uiState.update { state ->
                val selected = state.selectedGame?.let { cur ->
                    catalog.games.find { it.id == cur.id }
                } ?: catalog.games.firstOrNull()
                state.copy(games = catalog.games, selectedGame = selected)
            }
        }
    }

    fun selectGame(game: GameProfile) {
        _uiState.update { it.copy(selectedGame = game, results = emptyList()) }
    }

    fun scanSelectedGame() {
        val game = _uiState.value.selectedGame ?: return
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true) }
            val results = gamingRepository.benchmarkGame(game)
            _uiState.update { it.copy(results = results, isScanning = false) }
            val best = results.firstOrNull { it.stats.isReachable }
            if (best != null) {
                measurementDao.insert(
                    MeasurementEntity(
                        type = "GAMING",
                        networkType = game.nameEn,
                        isp = best.region.nameEn,
                        downloadMbps = 0.0,
                        uploadMbps = 0.0,
                        pingMs = best.stats.avgMs,
                        jitterMs = best.stats.jitterMs,
                        packetLossPercent = best.stats.packetLossPercent,
                        verdict = best.verdict.name
                    )
                )
            }
        }
    }

    fun setOverlayRunning(running: Boolean) {
        _uiState.update { it.copy(overlayRunning = running) }
    }
}
