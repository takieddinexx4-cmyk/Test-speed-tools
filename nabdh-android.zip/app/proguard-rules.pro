# Nabdh ProGuard / R8 Release Rules

# Kotlinx Serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class dz.nabdh.net.**$$serializer { *; }
-keepclassmembers class dz.nabdh.net.** {
    *** Companion;
}
-keepclasseswithmembers class dz.nabdh.net.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# OkHttp & Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Hilt / WorkManager
-keep class * extends androidx.work.ListenableWorker {
    public <init>(...);
}
