# موجه تصميم الشعار والأيقونة لمولّد الصور (PROMPT_LOGO.md)

## 1. أيقونة التطبيق (512x512 — Google Play High-Res Icon)
```text
Ultra-clean modern glassmorphism mobile app icon for an Algerian network speed & ping app named "Nabdh".
Centerpiece: a sleek, glowing Arabic letter "ن" (Noon) whose lower curve smoothly transforms into a sharp, dynamic digital ECG pulse wave.
Material & Lighting: translucent frosted glass squircle floating over a deep midnight navy to electric blue and vibrant turquoise gradient (#050B16 -> #0A4DFF -> #00E5C4), with subtle specular rim light and soft internal glow.
Heritage accent: subtle, refined Algerian flag micro-accents — the dot of the letter "ن" glowing in crisp crimson red (#D21034) with a fine white halo, and a delicate emerald green (#00A859) pulse endpoint dot.
Style: Apple/Material 3 flagship icon polish, centered composition, sharp vector-like geometry, no extra text, no watermarks, 1:1 aspect ratio.
```

## 2. صورة الغلاف للمتجر (1024x500 — Google Play Feature Graphic)
```text
Widescreen futuristic dark glassmorphism banner (1024x500) on a deep blue-turquoise animated mesh gradient background.
Left side: glowing frosted glass icon featuring the Arabic letter "ن" morphing into a cyan-turquoise pulse wave with subtle Algerian green, white, and red accents.
Right side: clean minimalist translucent glass cards showing an abstract glowing speedometer arc and smooth latency waveform, no readable text or watermarks, crisp studio lighting, high contrast, modern tech aesthetic.
```
