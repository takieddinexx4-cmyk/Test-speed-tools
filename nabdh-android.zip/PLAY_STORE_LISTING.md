# قائمة النشر على Google Play — نبض | Nabdh

## العربية (ar)
- **اسم التطبيق**: نبض — فحص السرعة والـ Ping
- **الوصف المختصر (80 حرفاً)**:
  أول تطبيق جزائري لقياس سرعة الإنترنت، استقرار Ping، وسيرفرات الألعاب بنافذة عائمة.
- **الوصف الكامل**:
  اكتشف الأداء الحقيقي لخط الإنترنت لديك مع **نبض | Nabdh**، أول تطبيق جزائري متكامل لفحص الشبكة بتصميم زجاجي عصري ودعم كامل للعربية والفرنسية والإنجليزية.
  - قياس سرعة التحميل والرفع بعدة اتصالات متوازية عبر Cloudflare مع إلغاء فوري.
  - فحص استقرار الـ Ping لمدة 30 أو 60 أو 120 ثانية مع حساب الانحراف المعياري والقفزات و100 حزمة لفقد الحزم.
  - وضع الألعاب لاختبار سيرفرات PUBG Mobile وFree Fire وCOD Mobile وValorant مع نافذة Ping عائمة فوق اللعبة.
  - سجل أسبوعي محفوظ على جهازك مع إمكانية مشاركة نتيجتك كصورة وتنبيهات ارتفاع الـ Ping.

## Français (fr)
- **Nom**: Nabdh — Test Débit & Ping DZ
- **Description courte**:
  Diagnostic réseau algérien : débit Cloudflare, stabilité Ping, serveurs Gaming & Overlay.
- **Description complète**:
  Mesurez la vraie qualité de votre connexion avec **Nabdh** : test de débit multi-connexions via Cloudflare, analyse de stabilité sur 30/60/120s, perte de 100 paquets, mode Gaming (PUBG Mobile, Free Fire, CODM, Valorant) avec fenêtre Ping flottante, historique 7 jours et alertes automatiques.

## English (en)
- **Title**: Nabdh — Speed, Ping & Gaming
- **Short description**:
  Algerian network diagnostics: Cloudflare speed test, Ping stability & Gaming overlay.
- **Full description**:
  Measure your real Internet performance with **Nabdh**: multi-connection Cloudflare speed tests with instant cancel, 30/60/120s Ping stability & 100-packet loss diagnostics, Gaming Mode (PUBG Mobile, Free Fire, CODM, Valorant) with a live draggable Ping overlay, 7-day history charts, and background Ping alerts.
