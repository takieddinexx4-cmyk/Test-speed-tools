# الخطوات اليدوية المطلوبة (MANUAL_STEPS.md)

نظراً لأن بيئة التوليد المعزولة لا تحتوي على Android SDK أو اتصال إنترنت أو مفتاح توقيع خاص بك، يلزم تنفيذ الخطوات التالية لإكمال البناء والنشر:

## 1. تشغيل البناء والاختبارات (عبر GitHub Actions أو جهازك)
- **عبر GitHub (من الهاتف مباشرة)**:
  1. ارفع ملف `nabdh-android.zip` (أو محتويات المستودع) إلى مستودعك على GitHub.
  2. شغّل سير العمل `Nabdh Android CI & Release` من تبويب **Actions**.
  3. سيعمل تلقائياً: `./gradlew assembleDebug` و`./gradlew testDebugUnitTest` و`./gradlew lintDebug` و`./gradlew assembleRelease`.
  4. حمّل ملف `app-debug.apk` أو `app-release-unsigned.apk` من قسم **Artifacts**.
- **محلياً (إن توفر Android Studio / SDK)**:
  ```bash
  ./gradlew assembleDebug testDebugUnitTest lintDebug assembleRelease
  ```

## 2. إنشاء مفتاح توقيع Release (Keystore)
1. أنشئ مفتاح التوقيع مرة واحدة واحفظه في مكان آمن:
   ```bash
   keytool -genkey -v -keystore nabdh-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias nabdh
   ```
2. أنشئ ملف `keystore.properties` في جذر المشروع (غير متتبع في git):
   ```properties
   storeFile=nabdh-release.jks
   storePassword=YOUR_STORE_PASSWORD
   keyAlias=nabdh
   keyPassword=YOUR_KEY_PASSWORD
   ```
   أو أضفها كـ GitHub Secrets (`NABDH_KEYSTORE_BASE64`, `NABDH_KEYSTORE_PASSWORD`, `NABDH_KEY_ALIAS`, `NABDH_KEY_PASSWORD`) ليتم توقيع Release تلقائياً في GitHub Actions.

## 3. اختبار على جهاز حقيقي
- ثبّت الـ APK على جهاز أندرويد (Android 8.0+ وجهاز Android 12+ للتحقق من Blur الحقيقي).
- امنح صلاحية **العرض فوق التطبيقات الأخرى** (Display over other apps) لاختبار الـ Overlay العائم أثناء تشغيل PUBG Mobile أو أي لعبة.
- امنح صلاحية **الإشعارات** (Android 13+) لتنبيهات ارتفاع Ping من WorkManager.

## 4. النشر على Google Play
1. أنشئ تطبيقاً جديداً في [Google Play Console](https://play.google.com/console).
2. ارفع حزمة `app-release.aab` الناتجة عن `./gradlew bundleRelease`.
3. انسخ النصوص الجاهزة من `PLAY_STORE_LISTING.md` وسياسة الخصوصية من `PRIVACY.md`.
4. استخدم `PROMPT_LOGO.md` لتوليد صورة المتجر عالية الدقة (512x512) وFeature Graphic (1024x500).
